
*****************************************************************
To Add the Option where you need to Delete a User through the GUI
*****************************************************************

Change to be made to the console file.
---------------------------------------


Open the s_frame.html and search for Change password and go to the end of the line and hit enter and at the beginning of the
new line add this code:

insertleaf(level1, buildleaf(2, "Delete MB{aim_user_variable.VALUE}ME Account","MB{s_link_program.VALUE}ME?AIMACTION=DeleteUser&ip_remote_user=EB{REMOTE_USER}EE&sqlquery1=query_get_all_user_login"))


Open the a_navigation.html and search for Change password and go to the end of the line and hit enter and at the beginning of the new line add this code:

{Delete MB{aim_user_variable.VALUE}ME Account*MB{s_link_program.VALUE}ME?AIMACTION=DeleteUser1&ip_remote_user=EB{REMOTE_USER}EE&sqlquery1=query_get_all_user_login*main}



Changes to be made the sp_states file.
--------------------------------------

Open the sp_states file and add the following code:

################### Delete User ########################

DeleteUser1=up_gsql staff/delete/s_finduserdelete.html
DeleteUser2=up_find staff/delete/s_finduserdeleteres.html
DeleteUser3=up_delete staff/delete/s_userdeleteres.html



Changes to be made the hd_obj file.
--------------------------------------

Open the hd_obj file and add the following code:

OBJECT{
	NAME=query_get_all_user_login
	VALUE=menulist_sub_login=select sub_login from users order by sub_login
};



Copying the Files.
-------------------

Please copy "FILES" only to the delete folder,under the helpdesk\client\aimhtml\hd\staff\delete folder.

