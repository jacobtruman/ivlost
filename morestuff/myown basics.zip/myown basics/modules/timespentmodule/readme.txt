***************************************************

** Implementing the Time Spent Module into the existing Software **

***************************************************

***************************
** Modifications to the hd_obj file**
***************************

In the hd_obj file search for the 'reports' object and make the necessary changes as below:

Add the following to the VALUE report/time_spent.html

Add the fillowing to the TITLE Time Spent Report.

After the modification the object should look something like this:

OBJECT{
	NAME=reports
        VALUE=report/time_spent.html^@report/percent_report.html^@report/percent_today.html^@report/Summary_Report.html^@report/Work_Order_Report.html^@report/Time_Elapsed_Report.html^$
	CONTROL=SYSTEM
	TYPE=MENU
        TITLE=Time Spent Report^@Percentage Report^@Activities For Today^@Summary Report^@Full Workorder^@Elapsed Time Report^$
};

Then Search for the 'report_show' object and make the necessary changes as below:

Add Running Total Report to the TITLE.

The object after modification would be something like this:

OBJECT{
	NAME=reports_show
	CONTROL=SYSTEM
	TYPE=MENU
        TITLE=Time Spent Report^@Percentage Report^@Summary Report^@Full Workorder^@Elapsed Time Report^$
};



******************
** Files to be copied **
******************

Copy the time_spent.html under the

$IPHOME\reports folder.

Where $IPHOME is the place where you have installed the software. By default it would be c:\helpdesk.


********************
** Editing the templates**
********************

$IPHOME\client\aimhtml\hd\staff\respond\s_respond.html

Respond Form:

1.Change the name="updateform" to name="submitform" in the <form> tag.

2. If you open the s_respond.html in a text editor such as notepad you will see a    javascript which you will need to modify by adding the following at the end:

Default Javascript Before Modification:

function updatestatus()
{
		var	sel;
		var	choice;
      var   who;
	
		sel=document.updateform.status.selectedIndex;
		choice=document.updateform.status.options[sel].text;
      who=document.updateform.assigned_to.value;

		if(choice=="FB{assigned_state.VALUE}FE"){
			document.updateform.status.options[sel].text="FB{pending_state.VALUE}FE";
	
		}else if(choice=="FB{open_state.VALUE}FE"){
			document.updateform.status.options[sel].text="FB{pending_state.VALUE}FE";
	
		}
	   if(who=="nobody"){
			document.updateform.assigned_to.value="EB{REMOTE_USER}EE";
	
	
		}
}



After the modification the script should read as follows:

function updatestatus()
{
		var	sel;
		var	choice;
      var   who;
	
		sel=document.submitform.status.selectedIndex;
		choice=document.submitform.status.options[sel].text;
      who=document.submitform.assigned_to.value;

		if(choice=="FB{assigned_state.VALUE}FE"){
			document.submitform.status.options[sel].text="FB{pending_state.VALUE}FE";
	
		}else if(choice=="FB{open_state.VALUE}FE"){
			document.submitform.status.options[sel].text="FB{pending_state.VALUE}FE";
	
		}
	   if(who=="nobody"){
			document.submitform.assigned_to.value="EB{REMOTE_USER}EE";
	
	
		}
r=checktime();
	return(r);

}
function checktime()
{
 
         var     num="";
         var     i;
        var     c;
        var     r;
        var     hr;
        var     min;
        var     val1;
        	var	r;
 
 
        val1=document.submitform.time_spent.value;
       	val="FB{time_spent.VALUE}FE";
        if(val1==""){
        	document.submitform.time_spent.value=val;
                return true;
        }
 
        for(i=0;i<val1.length;i++){
            c=val1.charAt(i);
            if((c=="0") ||(c=="1") ||(c=="2") ||(c=="3") ||(c=="4") ||(c=="5") ||(c=="6") ||(c=="7") ||(c=="8") ||(c=="9")){
                        ;
           }else{
                alert("Time format is wrong: It should be number of minutes.");
                return false ;
           }
        }
	if(isNaN(val)){
		val=0;
	}
        document.submitform.time_spent.value=parseInt(val)+parseInt(document.submitform.time_spent.value);
       return true;
}




3. You will have to delete the row for time spent from the existing template and add the following code instead:

 <tr>
            <td><font color="#000000" size="2"
            face="Verdana, Arial, Helvetica"><b>MB{time_spent.TITLE}ME</b></font></td>
            <td><font color="#000000"
            face="Verdana, Arial, Helvetica"><input type="text"
            size="25" name="time_spent"></font><font
            color="#000000" size="2"
            face="Verdana, Arial, Helvetica"><strong>Spent
            Already: FB{time_spent.VALUE}FE min</strong></font></td>
        </tr>

4. Save the file and test the changes.

5. You could create a time spent report on any criteria you may wish from the Metrics option from the System Managers and Administrators Tool.

