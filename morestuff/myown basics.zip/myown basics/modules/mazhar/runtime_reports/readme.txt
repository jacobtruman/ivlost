*************************************
** Modifications to the hd_obj file**
*************************************

In the hd_obj file search for the 'reports' object and make the necessary changes as below:

Add the following to the VALUE report/running_total.html

Add the fillowing to the TITLE Running Total Report.

After the modification the object should look something like this:

OBJECT{
	NAME=reports
        VALUE=report/running_total.html^@report/percent_report.html^@report/percent_today.html^@report/Summary_Report.html^@report/Work_Order_Report.html^@report/Time_Elapsed_Report.html^$
	CONTROL=SYSTEM
	TYPE=MENU
        TITLE=Running Total Report^@Percentage Report^@Activities For Today^@Summary Report^@Full Workorder^@Elapsed Time Report^$
};

Then Search for the 'report_show' object and make the necessary changes as below:

Add Running Total Report to the TITLE.

The object after modification would be something like this:

OBJECT{
	NAME=reports_show
	CONTROL=SYSTEM
	TYPE=MENU
        TITLE=Running Total Report^@Percentage Report^@Summary Report^@Full Workorder^@Elapsed Time Report^$
};

New object to be added:

OBJECT{
	NAME=running_total
	DBKEY=running_total
	TITLE=Running Total
};


****************************
** Database modifications **
****************************

Modify the database and add the field "running_total" to the 'problem' table or to the table
depending on the software.

************************
** Files to be copied **
************************

Copy the run_total_lib file from the zip file and copy it under the 

$IPHOME\client\aimhtml\hd\lib folder.

Copy the running_total.html under the

$IPHOME\reports folder.


**************************
** Editing the templates**
**************************

$IPHOME\client\aimhtml\hd\staff\submit\s_submit.html and 

$IPHOME\client\aimhtml\hd\staff\respond\s_respond.html

You will need to add a hidden field called "running_total" in both the templates.  

The syntax is as follows:

 
<input type="hidden" name="running_total" value="FB{running_total.VALUE}FE">

Add the onload="getloadtime()" inbetween the <body> and the </body> tags.

Before modification the code is 

<body bgcolor="#FFFFFF" text="#000000" link="#537EA0"
vlink="#537EA0" alink="#808080">

After modification it should look like this

<body bgcolor="#FFFFFF" text="#000000" link="#537EA0"
vlink="#537EA0" alink="#808080" onload="getloadtime()">


Also you will need to add the following:

LIBB{run_total_lib}LIBE on both the submit and the update form on top of the form.


If you open the s_submit.html in a text editor such as notepad you will see a javascript which you will need to modify by 
adding the following at the end:

   getsubmittime() and also modify the script

Before modifying the script the script would be as follows:

function updatestatus()
{
		var	sel;
		var	choice;
      var   who;
	
		sel=document.submitform.status.selectedIndex;
		choice=document.submitform.status.options[sel].text;
      who=document.submitform.assigned_to.value;

		if(choice=="FB{assigned_state.VALUE}FE"){
			document.submitform.status.options[sel].text="FB{pending_state.VALUE}FE";
	
		}else if(choice=="FB{open_state.VALUE}FE"){
			document.submitform.status.options[sel].text="FB{pending_state.VALUE}FE";
	
		}
	   if(who=="nobody"){
			document.submitform.assigned_to.value="EB{REMOTE_USER}EE";
	
	
		}
}



After the modification the script should read as follows:

function updatestatus()
{
      var	sel;
      var	choice;
      var   who;
	
		sel=document.submitform.status.selectedIndex;
		choice=document.submitform.status.options[sel].text;
      who=document.submitform.assigned_to.value;

		if(choice=="FB{assigned_state.VALUE}FE"){
			document.submitform.status.options[sel].text="FB{pending_state.VALUE}FE";
	
		}else if(choice=="FB{open_state.VALUE}FE"){
			document.submitform.status.options[sel].text="FB{pending_state.VALUE}FE";
	
		}
	   if(who=="nobody"){
			document.submitform.assigned_to.value="EB{REMOTE_USER}EE";
		}
	   getsubmittime()
}



If you open the s_respond.html in a text editor such as notepad you will see a javascript which you will need to modify by 
adding the following at the end:

   getsubmittime() and also modify the script

Before modifying the script the script would be as follows:

function updatestatus()
{
		var	sel;
		var	choice;
      var   who;
	
		sel=document.updateform.status.selectedIndex;
		choice=document.updateform.status.options[sel].text;
      who=document.updateform.assigned_to.value;

		if(choice=="FB{assigned_state.VALUE}FE"){
			document.updateform.status.options[sel].text="FB{pending_state.VALUE}FE";
	
		}else if(choice=="FB{open_state.VALUE}FE"){
			document.updateform.status.options[sel].text="FB{pending_state.VALUE}FE";
	
		}
	   if(who=="nobody"){
			document.updateform.assigned_to.value="EB{REMOTE_USER}EE";
	
	
		}
}



After the modification the script should read as follows:

function updatestatus()
{
      var	sel;
      var	choice;
      var   who;
	
		sel=document.submitform.status.selectedIndex;
		choice=document.submitform.status.options[sel].text;
      who=document.submitform.assigned_to.value;

		if(choice=="FB{assigned_state.VALUE}FE"){
			document.submitform.status.options[sel].text="FB{pending_state.VALUE}FE";
	
		}else if(choice=="FB{open_state.VALUE}FE"){
			document.submitform.status.options[sel].text="FB{pending_state.VALUE}FE";
	
		}
	   if(who=="nobody"){
			document.submitform.assigned_to.value="EB{REMOTE_USER}EE";
		}
	   getsubmittime()
}


The final thing to be changed is in the s_repond.html template is the name of the form in the <form> tag should be changed 
from name="updateform" to name="submitform". By default it is name="updateform".
