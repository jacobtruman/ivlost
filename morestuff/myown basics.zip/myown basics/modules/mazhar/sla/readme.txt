********************************************
** Objects to be added in the hd_obj file **
********************************************

The objects in the object.txt file in the zip file have to be added in the hd_obj file.

Note: There are objects in the object.txt file which are related to the case number mapping,
if the mapping already exists in the hd_obj file ignore those objects. There are three object
case_num-map, case_num-picture, infotype-prefix. If all these objects already exists in the 
object file you need not have to include these again but add an entry for the SLA in that object.

**************************
** Case_num file changes**
**************************

The entry you have made in the infotype-prefix object that entry has to be added in the case_num
file exactly the same way as in the infotype-prefix object and this is case sensitive, and
give it a starting number of your choice. For example you want the SLA to start being numbered
from 2000 on you have to make an entry in the case_num file as SLA    2000.

******************************
** SLA Table in the database**
******************************

The SLA table has to be imported from the problem_track_sla.mdb to the default database in
the software. If helpdesk the database name is problem_track and may be different for the 
product purchased.

*******************************
** Changes to sp_states file **
*******************************

The entries in the sp_states.txt have to be added in the sp_states file.


*****************************
** New folder to be copied **
*****************************

The folder sla under the aimhtmlhdstaff folder has to be copied under the 
$IPHOME\client\aimhtml\hd\staff folder

**************************
** Console file changes **
**************************

The code in the a_vmain.txt has to be added in the a_vmain.html file.

**********************
** Template Changes **
**********************

There are two templates which you need to modify.

$IPHOME\client\aimhtml\hd\users\submit\u_submit.html

$IPHOME\client\aimhtml\hd\staff\submit\s_submit.html

You have to pass the infotype value as a hidden field in both the templates, the code is :

<input type="hidden" name="infotype.VALUE" value="SLA">

The value in the above code has to match exactly to what you have in the infotype-prefix object
in the TITLE field.


