********************
** Copy the Dll's **
********************

Copy the 4 DLL's from the zip file to winnt\system32 folder on your NT machine.


*******************************************
** Object to be added in the hd_obj file **
*******************************************

OBJECT{
	NAME=ldap_control
	VALUE=63.90.195.70:389:o=AIM
	TITLE=uid^@submitted_by^$cn^@sub_name^$mail^@sub_e_mail^$department^@sub_dept^$telephoneNumber^@sub_phone^$
};

Where 63.90.195.70 is the LDAP server's IPAddress and 389 is the default port and o=AIM is the
base name, ':' is the field seperator.

The values in the Title field are the mappings from the LDAP server's fileds to the software
fields separated by ^$ at the end of each mappings.

**********************************************************
** Object to be deleted and Modified in the hd_obj file **
**********************************************************

Delete all entries relating to the user/submittor.

OBJECT{
	NAME=sub_login
	DBKEY=sub_login
	CONTROL=SYSTEM
};

OBJECT{
	NAME=db_users_table_name
	VALUE=users
	CONTROL=SYSTEM
};

OBJECT{
	NAME=sql_lookup_a_user
	CONTROL=users
};

OBJECT{
	NAME=sql_sort_users_by_login
	TITLE=sub_login
};

The above object should be deleted from the hd_obj file.


Modify the following object:

OBJECT{
	NAME=sql_one_ticket_join_lookup
	VALUE=assigned_to=sa_login and submitted_by=sub_login
	CONTROL=problem, staff, users
};


After modification the object should read as follows:


OBJECT{
	NAME=sql_one_ticket_join_lookup
	VALUE=assigned_to=sa_login
	CONTROL=problem, staff
};


***************************************************
** Modifications to be made to the console files **
***************************************************

Users Side:


Please delete the following lines from the u_vmain.html if using a non-java console:

<td><a href="MB{link_program.VALUE}ME?AIMACTION=Profile&amp;amp;ip_remote_user=EB{REMOTE_USER}EE&amp;row2form_rec.VALUE=findmyrec_sub_login&amp;sql_control=sql_lookup_a_user"><font
        size="2" face="Verdana, Arial, Helvetica"><strong>Profile</strong></font></a></td>
</tr>

If using a Java Console:

level1 = insertnode(roothandle, newnode("<strong><b>Account</b></strong>"));
insertleaf(level1, buildleaf(2, "Profile","MB{link_program.VALUE}ME?AIMACTION=Profile&amp;ip_remote_user=EB{REMOTE_USER}EE&row2form_rec.VALUE=findmyrec_sub_login&sql_control=sql_lookup_a_user"))

Staff Side:

Please delete the following lines from the s_vmain.html and a_vmain.html:

level1 = insertnode(roothandle, newnode("<strong><b>User Accounts</b></strong>"));
insertleaf(level1, buildleaf(2, "Create User Account","MB{s_link_program.VALUE}ME?AIMACTION=CreateUser&amp;ip_remote_user=EB{REMOTE_USER}EE"))
insertleaf(level1, buildleaf(2, "Modify User Profiles","MB{s_link_program.VALUE}ME?AIMACTION=EditUser&amp;ip_remote_user=EB{REMOTE_USER}EE"))


******************************
** Templates to be replaced **
******************************


All the below templates are in the zip file which have to be replaced.


Staff side:

$IPHOME\client\aimhtml\hd\staff\delete\s_finddelete.html

$IPHOME\client\aimhtml\hd\staff\respond\s_respond.html

$IPHOME\client\aimhtml\hd\staff\respond\s_findrespond.html

$IPHOME\client\aimhtml\hd\staff\submit\s_findprofilesubmit.html	

$IPHOME\client\aimhtml\hd\staff\submit\s_findprofilesubmitres.html

$IPHOME\client\aimhtml\hd\staff\submit\s_submit.html

$IPHOME\client\aimhtml\hd\staff\users\s_viewprofile.html

$IPHOME\client\aimhtml\hd\staff\viewcase\s_viewcase.html



Users side:

$IPHOME\client\aimhtml\hd\users\update\u_escalate.html

$IPHOME\client\aimhtml\hd\users\viewcase\u_viewcase.html




**********************************************
** Changes to be made in the up_states file **
**********************************************

Open the up_states file and change the following line from:

vmain=up_row2form users/console/u_vmain.html

TO:

vmain=up_startup users/console/u_vmain.html  

Change the following from:

Submit=up_row2form users/submit/u_submit.html

TO:

Submit=up_startup users/submit/u_submit.html


