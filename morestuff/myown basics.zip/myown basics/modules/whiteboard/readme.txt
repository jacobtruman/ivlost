********************************************
** Objects to be added in the hd_obj file **
********************************************

The objects in the hd_obj.txt file in the zip file have to be added in the hd_obj file.

Note: There are objects in the hd_obj.txt file which are related to the case number mapping,
if the mapping already exists in the hd_obj file ignore those objects. There are three object
case_num-map, case_num-picture, infotype-prefix. If all these objects already exists in the 
object file you need not have to include these again but add an entry for the CS in that object.

**************************
** Case_num file changes**
**************************

The entry you have made in the infotype-prefix object that entry has to be added in the case_num
file exactly the same way as in the infotype-prefix object and this is case sensitive, and
give it a starting number of your choice. For example you want the Whiteboard to start being numbered
from 2000 on you have to make an entry in the case_num file as W    2000.

************************************
**Messages Table in the database **
************************************

The messages table has to be imported from the problem_track_faq.mdb to the default database in
the software. If helpdesk the database name is problem_track and may be different for the 
product purchased.

*******************************
** Changes to sp_states file **
*******************************

The entries in the sp_states.txt have to be added in the sp_states file.


*******************************
** Changes to up_states file **
*******************************

The entries in the up_states.txt have to be added in the up_states file.


************************
** Copy the templates **
************************

Copy the templates u_vtasks.html to the

$IPHOME\client\aimhtml\hd\users\console folder.

Copy the template s_vtasks.html to the

$IPHOME\client\aimhtml\hd\staff\console folder.


*********************************************
** Changes to be made in the console files **
*********************************************

The code in the a_s_vmain.txt has to be added in the

$IPHOME\client\aimhtml\hd\staff\console\a_vmain.html and

$IPHOME\client\aimhtml\hd\staff\console\s_vmain.html 


The code below has to be added to the s_submit.html if you are using the case_num mapping.

<input type="hidden" name="infotype.VALUE" value="Whiteboard"> 

The value in the above code has to match exactly to what you have in the infotype-prefix object
in the TITLE field.


In all the three console files the following changes have to be made.

**u_vmain.html:**

At the bottom of the file search for this line:

<FRAME SRC="MB{link_program.VALUE}ME?AIMACTION=Knowledge&amp;ip_remote_user=EB{REMOTE_USER}EE" name="outputframe">

You have to delete the entire code starting from AIMACTION till the end and replace it with
the following line:

AIMACTION=vtasks&amp;ip_remote_user=EB{REMOTE_USER}EE&db_table_name.VALUE=MB{db_whiteboard_table_name.VALUE}ME&msg_status.VALUE=Active&sort_titles1_menu.VALUE=LFB{message_type.TITLE}LFE" name="outputframe">

**a_vmain.html:**

At the bottom of the file search for this line:

<FRAME SRC="MB{s_link_program.VALUE}ME?AIMACTION=Create+Report&amp;ip_remote_user=EB{REMOTE_USER}EE&date_mod.VALUE=EB{TODAY}EE&reports_menu.VALUE=Activities+For+Today&sql_control=sql_one_ticket_join_lookup" name="outputframe"> 

You have to delete the entire code starting from AIMACTION till the end and replace it with
the following line:

AIMACTION=vtasks&amp;ip_remote_user=EB{REMOTE_USER}EE&db_table_name.VALUE=MB{db_whiteboard_table_name.VALUE}ME&msg_status.VALUE=Active&sort_titles1_menu.VALUE=LFB{message_type.TITLE}LFE" name="outputframe">


**s_vmain.html:**

At the bottom of the file search for this line:

<FRAME SRC="MB{s_link_program.VALUE}ME?AIMACTION=Find+Ticket(s)+to+Update&amp;ip_remote_user=EB{REMOTE_USER}EE&assigned_to.VALUE===EB{REMOTE_USER}EE&status.VALUE=FB{nonclosed_states.VALUE}FE&VB{sort_titles1_menu.VALUE}VE=LFB{case_num.TITLE}LFE" name="outputframe"> 

You have to delete the entire code starting from AIMACTION till the end and replace it with
the following line:

AIMACTION=vtasks&amp;ip_remote_user=EB{REMOTE_USER}EE&db_table_name.VALUE=MB{db_whiteboard_table_name.VALUE}ME&msg_status.VALUE=Active&sort_titles1_menu.VALUE=LFB{message_type.TITLE}LFE" name="outputframe">





**************************
** Folders to be copied **
**************************


The folder whiteboard under the aimhtmlhdstaff has to be copied under the

$IPHOME\client\aimhtml\hd\staff folder.


