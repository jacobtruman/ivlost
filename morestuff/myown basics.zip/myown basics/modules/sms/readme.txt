
Please have the latest version of the binaries.


********************************************
** Objects to be added in the hd_obj file **
********************************************

OBJECT{
	NAME=hostname
	DBKEY=hostname
	TITLE=Hostname
};

You have add a new text field to the table in the database depending on what software is purchased by the 
Customer if it is a helpdesk system then the table which you need to add the field is problem in the problem_track.mdb
 
OBJECT{
	NAME=sms_all_prop
	VALUE=SMS:sms:sms123
	TITLE=Boot_Configuration_DATA^@CD_ROM_DATA^@Computer_System_DATA^@Disk_DATA^@Display_Configuration_DATA^@Display_Controller_Config_DATA^@Driver_VxD_DATA^@Keyboard_DATA^@Logical_Disk_DATA^@Modem_DATA^@Motherboard_DATA^@Mouse_DATA^@Netcard_DATA^@Network_Client_DATA^@Network_DATA^@Operating_System_DATA^@Parallel_Port_DATA^@Partition_DATA^@PC_BIOS_DATA^@PC_Memory_DATA^@Processor_DATA^@SCSI_Controller_DATA^@Services_DATA^@Sites_DATA^@Tape_Drive_DATA^@Video_DATA^@WorkstationStatus_DATA^@Y2K_Software_Complian_DATA^$
};

This is the object to be added in the and the values in the TITLE field should not be altered
as these are the table names in the SMS database.

The value in the VALUE field should consist of the dbname:dbuser:password, where ':' is the 
separator. The values in the above object is an example. Where SMS is the name of the database,
sms is the user id and sms123 is the password for the user authorized to use the database.

***********************************
** Making a new Data Source Name **
***********************************

Make sure that you create a new datasource name with the same name as the Database name.

For example if you have the SMS as your database you will have to create a DSN with SMS. This 
DSN will have to be created using the SQL driver and it should be pointing to the Database you
have mentioned in the sms_all_prop object.

********************************
** Changes to the states file **
********************************

sp_states:

The states from the sp_states.txt has to be added in the sp_states file.


************************
** files to be copied **
************************

The smsgui and the smskeys files in the zip file has to be added under the 

$IPHOME\client\config folder.


The u_submit.html file has to be added in the 

$IPHOME\client\aimhtml\hd\users\submit folder.

The s_submit.html file has to be added in the 

$IPHOME\client\aimhtml\hd\staff\submit folder.

The s_respond.html file hs to be added in the 

$IPHOME\client\aimhtml\hd\staff\respond folder.

Copy the sms folder under the

$IPHOME\client\aimhtml\hd\staff\ folder.

