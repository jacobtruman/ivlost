********************************************
** Objects to be added in the hd_obj file **
********************************************

The objects in the hdobjfile.txt have to be added in the hd_obj file. Make sure that the 
attachdir and the pre_attachdir is pointing to the correct location. Also please ask the 
customer to create a new folder under the $IPWEB folder called attachments and have change
permissions to that folder. Where $IPWEB is the name of the folder under the webserver 

For example : c:/inetpub/wwwroot/helpdesk/attachments on NT

NOTE: Make sure that this folder allows full access to users.

***********************************************
** Objects to be added in the sp_states file **
***********************************************

Add the following State to the sp_states file:

delete_attachment=up_delete staff/attachment/s_deleteres.html

*******************************************
** Changes to be made on the submit form **
*******************************************

The code in the submitform.txt has to be added in the 

$IPHOME\client\aimhtml\staff\submit\s_submit.html and 

$IPHOME\client\aimhtml\users\submit\u_submit.html

This code has to be added at the bottom of the table before the submit and reset buttons on both of the submit forms.


*********************************************
** Changes to be made on the respond forms **
*********************************************

The code in the repondform.txt has to be added in the 

$IPHOME\client\aimhtml\staff\respond\s_respond.html and 

$IPHOME\client\aimhtml\users\update\u_escalate.html

This code has to be added in both the respond forms at the bottom of the table.

You will also need to add the following code to each of the header's jump links:

	<FONT COLOR="#808080" SIZE="1" FACE="Verdana, Arial, Helvetica">
		|
	</FONT>
	<FONT COLOR="#FFFFFF" SIZE="1" FACE="Verdana, Arial, Helvetica">
		<A HREF="#attachments">
			MB{aim_attach_variable.VALUE}ME
		</A>
	</FONT>

Then add the following code with the other libraries:

LIBB{attach_icons.js}LIBE
LIBB{confirm_delete.js}LIBE


**********************************************
** Changes to be made to the view templates **
**********************************************

The code in the viewform.txt has to be added in the 

$IPHOME\client\aimhtml\staff\viewcase\s_viewcase.html and 

$IPHOME\client\aimhtml\users\viewcase\u_viewcase.html

This code has to be added at the end or the viewcase templates.

You will also need to add the following code to each of the header's jump links:

	<FONT COLOR="#808080" SIZE="1" FACE="Verdana, Arial, Helvetica">
		|
	</FONT>
	<FONT COLOR="#FFFFFF" SIZE="1" FACE="Verdana, Arial, Helvetica">
		<A HREF="#attachments">
			MB{aim_attach_variable.VALUE}ME
		</A>
	</FONT>

NOTE: ALL THE ABOVE CODE MUST BE ADDED WITHIN THE <FORM> and </FORM> TAGS IN EVERY TEMPLATE.

Then add the following code with the other libraries:

LIBB{attach_icons.js}LIBE


**************************
** Folders to be copied **
**************************

The folder attachpics has to be copied under the

$IPWEB\wwwroot\$IPHOME folder.  (Example: c:\Inetpub\wwwroot\helpdesk)

The folder attachment has to be copied under the

$IPHOME\client\config\aimhtml\hd\staff folder.


*******************************
** Javascripts to be coppied **
*******************************

Copy the attach_icons.js and the confirm_delete.js to the

$IPHOME\client\aimhtml\hd\lib folder.