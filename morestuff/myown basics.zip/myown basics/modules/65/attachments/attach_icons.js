<SCRIPT LANGUAGE="JavaScript">
/*
* NAME: attach_icons.js
* DESC: Script to add images to attachments icons.
* To add images to the script simple add a gif image w:34 h:32 to attachpics dir under IPWEB
* Name the image after the file extension you want to associate with. Example: doc.gif
* AUTHOR: Applied Innovation Management.
* NOTE: Copyright (c) 2001. All Rights Reserved.
*/
	
	var maxattach = 0
		 function checkImage(picsdir)
				{
     for (var x=1; x<=maxattach; x++)
							{
     			iconname = eval("document.icon" + x)
        if (iconname.complete==false)
									{
          iconname.src = picsdir + "other.gif"
         }
     	}
			}
	function showIcon(pre_attach, filename, picsdir, imagenum)
					{     
     	var fileext = filename.substring(filename.length - 4, filename.length)
     	if (fileext.substring(0, 1) == ".")
							{
	     	fileext = fileext.substring(1, fileext.length)
     		}
					document.write("<img name='icon" + imagenum + "' src='" + picsdir + fileext + ".gif' border='0'>")
					document.close()
						maxattach = Number(imagenum)
				}
	
</SCRIPT>