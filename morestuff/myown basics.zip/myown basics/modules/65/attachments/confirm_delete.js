<SCRIPT LANGUAGE="JavaScript">
/*
* NAME: confirm_delete.js
* DESC: Script to confirm deletion of attachments.
* AUTHOR: Applied Innovation Management.
* NOTE: Copyright (c) 2001. All Rights Reserved.
*/
	function confirmdelete(att)
{
	var ans;
	ans=confirm("You Are About To Delete Attachment '"+att+"'."+"\nDo You Wish To Continue?");
	if(ans==false){
		return (false);
	}else{
		return (true);

	}
}
</SCRIPT>