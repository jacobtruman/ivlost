********************************************
** Objects to be added in the hd_obj file **
********************************************

The objects in the hd_obj.txt file in the zip file have to be added in the hd_obj file.

Note: There are is an object in the hd_obj file which is related to the case number mapping.  It is the infotype-prefix object. You will need to modify this object to include the Customer Satisfaction Survey.
EXAMPLE:
FROM:

OBJECT{
	NAME=infotype-prefix
	VALUE=HD^$
	TYPE=MENU
	TITLE=Ticket^$
};

To:

OBJECT{
	NAME=infotype-prefix
	VALUE=HD^@CS^$
	TYPE=MENU
	TITLE=Ticket^@Customer Surveys^$
};

You will also have to add the following values to the enforce_fields object:

^@cs_type^@cs_submitter^@cs_exper^@cs_sat

It should look something like this when done:

OBJECT{
	NAME=enforce_fields

VALUE=sub_access^@category^@sa_access^@sa_e_mail^@sa_login^@sa_permissions^@sub_e_mail^@sub_login^@sub_name^@problem^@short_desc^@status^@cs_type^@cs_submitter^@cs_exper^@cs_sat^$
;


************************************
** Changes to be made for Reports **
************************************

STEP 1:

You will need to add the following to the 'reports' object:
To the 'VALUE':

^@report/custsat_percent_report.html^@report/custsat_Work_Order_Report.html^@report/custsat_trend_report.html

To the 'TITLE':

^@Percentage Report (Customer Survey)^@Full Workorder (Customer Survey)^@Trend Report  (Customer Survey)

It should look something like this when done:

OBJECT{
	NAME=reports
	VALUE=report/percent_report.html^@report/summary_report.html^@report/work_order_report.html^@report/time_elapsed_report.html^@report/trend_report.html^@report/time_spent.html^@report/custsat_percent_report.html^@report/custsat_Work_Order_Report.html^@report/custsat_trend_report.html^$
	CONTROL=SYSTEM
	TYPE=MENU
	TITLE=Percentage Report^@Summary Report^@Full Workorder^@Elapsed Time Report^@Trend Report^@Time Spent Report^@Percentage Report (Customer Survey)^@Full Workorder (Customer Survey)^@Trend Report (Customer Survey)^$
};


STEP 2:

Then open s_advancedreports.html, located under $IPHOME/client/aimhtml/hd/staff/reports folder ($IPHOME being the location the software is installed.  Ex: c:/helpdesk).  Search for the following code:

        <TR>
            <TD BGCOLOR="#537EA0" colspan="2">
            	<B>
            		<FONT COLOR="#FFFFFF" FACE="Verdana, Arial, Helvetica" SIZE="1">
            			Report Format </FONT></B><FONT COLOR="#000000" SIZE="2" FACE="Verdana, Arial, Helvetica">
            		<SELECT NAME="reports_menu" SIZE="1" CLASS='formfield'>
	                  	<option>DB{reports.TITLE}DE</option>
            		</SELECT>
            	</FONT>
            </TD>
        </TR>

Modify the DB{reports.TITLE}DE to look like this: DB{reports_show.TITLE}ME.  It should look like this when done:

        <TR>
            <TD BGCOLOR="#537EA0" colspan="2">
            	<B>
            		<FONT COLOR="#FFFFFF" FACE="Verdana, Arial, Helvetica" SIZE="1">
            			Report Format </FONT></B><FONT COLOR="#000000" SIZE="2" FACE="Verdana, Arial, Helvetica">
            		<SELECT NAME="reports_menu" SIZE="1" CLASS='formfield'>
	                  	<option>DB{reports_show.TITLE}DE</option>
            		</SELECT>
            	</FONT>
            </TD>
        </TR>

STEP 3:

You will need to add to the 'trend_report_fields' object:
To the 'VALUE':

cs_type^@cs_exper^$cs_type^@cs_sat^$cs_type^@cs_timely^$

It should look something like this when done:

OBJECT{
	NAME=trend_report_fields
	VALUE=status^@assigned_to^$category^@assigned_to^$category^@priority_type^$status^@category^$priority_type^@assigned_to^$status^@priority_type^$cs_type^@cs_exper^$cs_type^@cs_sat^$cs_type^@cs_timely^$
};


**************************
** Case_num file changes**
**************************

The entry you have made in the infotype-prefix object that entry has to be added in the case_num
file exactly the same way as in the infotype-prefix object and this is case sensitive, and
give it a starting number of your choice. For example you want the Customer Surveys to start being numbered
from 2000 on you have to make an entry in the case_num file as CS 2000.

*******************************************
** Customer Survey Table in the database **
*******************************************

The custsat table has to be imported from the problem_track_cust.mdb to the default database in
the software. If helpdesk the database name is problem_track and may be different for the 
product purchased.

*******************************
** Changes to sp_states file **
*******************************

The entries in the sp_states.txt have to be added in the sp_states file.


*******************************
** Changes to up_states file **
*******************************

The entries in the up_states.txt have to be added in the up_states file.


*********************************************
** Changes to be made in the console files **
*********************************************

The code in the s_frame.txt has to be added in the

$IPHOME\client\aimhtml\hd\staff\console\s_frame.html 

The code in the a_navigation.txt has to be added in the

$IPHOME\client\aimhtml\hd\staff\console\a_navigation.html 

The code in the u_frame.txt has to be added to 

$IPHOME\client\aimhtml\hd\users\console\u_frame.html

The code in the u_navigation.txt has to be added to 

$IPHOME\client\aimhtml\hd\users\console\u_navigation.html



**************************
** Folders to be copied **
**************************

The folder survey under the aimhtmlhduser folder has to be copied under the 

$IPHOME\client\aimhtml\hd\users folder and 

The folder survey under the aimhtmlhdstaff has to be copied under the

$IPHOME\client\aimhtml\hd\staff folder.


************************
** Files to be copied **
************************

Copy the files in the surveyreports folder to the

$IPHOME\report folder


Copy the finderror_css.html to the

$IPHOME\client\aimhtml\hd folder
