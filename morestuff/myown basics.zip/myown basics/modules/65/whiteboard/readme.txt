********************************************
** Objects to be added in the hd_obj file **
********************************************

The objects in the hd_obj.txt file in the zip file have to be added in the hd_obj file.



*********************************************
** Objects to be edited in the hd_obj file **
*********************************************

Search for the object infotype-prefix, you should find:

OBJECT{
	NAME=infotype-prefix
	VALUE=HD^$
	TYPE=MENU
	TITLE=Ticket^$
};

add MS to the VALUE seperating all entries with ^@ end the string with ^$
add Message to the TITLE seperating all entries with ^@ end the string with ^$
So now our object should look like this:
OBJECT{
	NAME=infotype-prefix
	VALUE=HD^@MS^$
	TYPE=MENU
	TITLE=Ticket^@Message^$
};

**Note if you have other modules you may have more entries under the VALUE and TITLE

Search for the object enforce_fields, you should find something similar to this:

OBJECT{
	NAME=enforce_fields

VALUE=sub_access^@category^@sa_access^@sa_e_mail^@sa_login^@sa_permissions^@sub_e_mail^@sub_login^@sub_name^@problem^@short_desc^@status^$
};

add the following entries to the VALUE seperating all entries with ^@ and end the string with ^$:

wb_message^@wb_msg_title^@wb_msg_status^@wb_msg_type^@wb_effected_area^$


you should now have something like this(fields will vary depending on what you have enforced):

OBJECT{
	NAME=enforce_fields

VALUE=sub_access^@category^@sa_access^@sa_e_mail^@sa_login^@sa_permissions^@sub_e_mail^@sub_login^@sub_name^@problem^@short_desc^@status^@wb_message^@wb_msg_title^@wb_msg_status^@wb_msg_type^@wb_effected_area^$
};



**************************
** Case_num file changes**
**************************

The entry you have made in the infotype-prefix object that entry has to be added in the case_num
file exactly the same way as in the infotype-prefix object and this is case sensitive, and
give it a starting number of your choice. For example you want the Whiteboard to start being numbered
from 2000 on you have to make an entry in the case_num file as MS    2000.



************************************
**Messages Table in the database **
************************************

The messages table has to be imported from the problem_track_messages.mdb to the default database in
the software. If helpdesk the database name is problem_track and may be different for the 
product purchased.



*******************************
** Changes to sp_states file **
*******************************

The entries in the sp_states.txt have to be added in the sp_states file.


*******************************
** Changes to up_states file **
*******************************

The entries in the up_states.txt have to be added in the up_states file.


************************
** Copy the templates **
************************

Copy the template u_vtasks.html to the

$IPHOME\client\aimhtml\hd\users\console folder.

Copy the template s_vtasks.html to the

$IPHOME\client\aimhtml\hd\staff\console folder.

Copy the template finderror_msg.html to the

$IPHOME\client\aimhtml\hd folder.


**************************
** Folders to be copied **
**************************


The folder whiteboard under the aimhtmlhdstaff has to be copied under the

$IPHOME\client\aimhtml\hd\staff folder.

*********************************************
** Changes to be made in the console files **
*********************************************

*****a_navigation.html & s_navigation.html*****

Add the following code:

{MB{aim_wb_variable.VALUE}ME{Submit MB{aim_msg_variable.VALUE}ME*MB{s_link_program.VALUE}ME?AIMACTION=Message1&ip_remote_user=EB{REMOTE_USER}EE&enforce_color=ON*main}
{Update MB{aim_msg_variable.VALUE}ME*MB{s_link_program.VALUE}ME?AIMACTION=Message3&ip_remote_user=EB{REMOTE_USER}EE*main}
{View MB{aim_wb_variable.VALUE}ME*MB{s_link_program.VALUE}ME?AIMACTION=vtasks&ip_remote_user=EB{REMOTE_USER}EE&db_table_name.VALUE=MB{db_wb_table_name.VALUE}ME&wb_msg_status.VALUE=Active&sort_titles1_menu.VALUE=LFB{wb_msg_type.TITLE}LFE&error_template=finderror_msg.html*main}
}

*****s_frame.html & s_vmain*****

Add the following code: 

level1 = insertnode(roothandle, newnode("<strong><b>MB{aim_wb_variable.VALUE}ME</b></strong>"));
	insertleaf(level1, buildleaf(2, "Submit MB{aim_msg_variable.VALUE}ME","MB{s_link_program.VALUE}ME?AIMACTION=Message1&ip_remote_user=EB{REMOTE_USER}EE&enforce_color=ON"))
	insertleaf(level1, buildleaf(2, "Update MB{aim_msg_variable.VALUE}ME","MB{s_link_program.VALUE}ME?AIMACTION=Message3&ip_remote_user=EB{REMOTE_USER}EE"))
	insertleaf(level1, buildleaf(2, "View MB{aim_wb_variable.VALUE}ME","MB{s_link_program.VALUE}ME?AIMACTION=vtasks&ip_remote_user=EB{REMOTE_USER}EE&db_table_name.VALUE=MB{db_wb_table_name.VALUE}ME&wb_msg_status.VALUE=Active&sort_titles1_menu.VALUE=LFB{wb_msg_type.TITLE}LFE&error_template=finderror_msg.html"))

*****s_frame.html:*****

Search for this line:

	document.write("<FRAME SRC='MB{s_link_program.VALUE}ME?AIMACTION=Respond2&ip_remote_user=EB{REMOTE_USER}EE&sql_control=sql_one_ticket_join_lookup&assigned_to.VALUE===EB{REMOTE_USER}EE&status.VALUE=FB{nonclosed_states.VALUE}FE&VB{sort_titles1_menu.VALUE}VE=LFB{case_num.TITLE}LFE&carry_one=LODB{sa_permissions.VALUE}LODE&pcstr=<LI><b>LFB{assigned_to.TITLE}LFE:</b>+EB{REMOTE_USER}EE<br><LI>+<b>LFB{status.TITLE}LFE:</b>+LFB{nonclosed_states.VALUE}LFE<br>&cstr=LFB{assigned_to.TITLE}LFE=EB{REMOTE_USER}EE|MB{status.TITLE}ME=LFB{nonclosed_states.VALUE}LFE' name='outputframe'>");

And replace it with this line: 

	document.write("<FRAME SRC='MB{s_link_program.VALUE}ME?AIMACTION=AIMACTION=vtasks&ip_remote_user=EB{REMOTE_USER}EE&db_table_name=MB{db_wb_table_name.VALUE}ME&wb_msg_status=Active&sort_titles1_menu.VALUE=LFB{wb_msg_type.TITLE}LFE&error_template=finderror_msg.html' NAME='outputframe'>");

Search for this line (this line is in the console twice and both instances should be replaced):

document.write("<FRAME SRC='MB{s_link_program.VALUE}ME?AIMACTION=Respond2&ip_remote_user=EB{REMOTE_USER}EE&sql_control=sql_one_ticket_join_lookup&assigned_to.VALUE===EB{REMOTE_USER}EE&status.VALUE=FB{nonclosed_states.VALUE}FE&VB{sort_titles1_menu.VALUE}VE=LFB{case_num.TITLE}LFE&carry_one=LODB{sa_permissions.VALUE}LODE&pcstr=<LI><b>LFB{assigned_to.TITLE}LFE:</b>+EB{REMOTE_USER}EE<br><LI>+<b>LFB{status.TITLE}LFE:</b>+LFB{nonclosed_states.VALUE}LFE<br>&cstr=LFB{assigned_to.TITLE}LFE=EB{REMOTE_USER}EE|MB{status.TITLE}ME=LFB{nonclosed_states.VALUE}LFE' NAME='main'>");

And Replace it with this line:

document.write("<FRAME SRC='MB{s_link_program.VALUE}ME?AIMACTION=vtasks&ip_remote_user=EB{REMOTE_USER}EE&db_table_name.VALUE=MB{db_wb_table_name.VALUE}ME&wb_msg_status.VALUE=Active&sort_titles1_menu.VALUE=LFB{wb_msg_type.TITLE}LFE&error_template=finderror_msg.html' NAME='main'>");


**s_vmain.html:**

At the bottom of the file search for this line:

<FRAME SRC='MB{s_link_program.VALUE}ME?AIMACTION=Respond2&ip_remote_user=EB{REMOTE_USER}EE&sql_control=sql_one_ticket_join_lookup&assigned_to.VALUE===EB{REMOTE_USER}EE&status.VALUE=FB{nonclosed_states.VALUE}FE&VB{sort_titles1_menu.VALUE}VE=LFB{case_num.TITLE}LFE&carry_one=LODB{sa_permissions.VALUE}LODE&pcstr=<LI><b>LFB{assigned_to.TITLE}LFE:</b>+EB{REMOTE_USER}EE<br><LI>+<b>LFB{status.TITLE}LFE:</b>+LFB{nonclosed_states.VALUE}LFE<br>&cstr=LFB{assigned_to.TITLE}LFE=EB{REMOTE_USER}EE|MB{status.TITLE}ME=LFB{nonclosed_states.VALUE}LFE' name='outputframe'>

and Replace it with this line:

<FRAME SRC='MB{s_link_program.VALUE}ME?AIMACTION=vtasks&ip_remote_user=EB{REMOTE_USER}EE&db_table_name.VALUE=MB{db_wb_table_name.VALUE}ME&wb_msg_status.VALUE=Active&sort_titles1_menu.VALUE=LFB{wb_msg_type.TITLE}LFE&error_template=finderror_msg.html' name='outputframe'>


*****u_frame.html:*****

Search for this line:

	document.write("<FRAME SRC='MB{link_program.VALUE}ME?AIMACTION=Submit1&ip_remote_user=EB{REMOTE_USER}EE&row2form_rec.VALUE=findmyrec_sub_login&sql_control=sql_lookup_a_user&enforce_color=ON' name='outputframe'>");

and Replace it with this line:

	document.write("<FRAME SRC='MB{link_program.VALUE}ME?AIMACTION=vtasks&ip_remote_user=EB{REMOTE_USER}EE&db_table_name.VALUE=MB{db_wb_table_name.VALUE}ME&wb_msg_status.VALUE=Active&sort_titles1_menu.VALUE=LFB{wb_msg_type.TITLE}LFE&error_template=finderror_msg.html' name='outputframe'>");

NEXT

Search for this line:

	document.write("<FRAME SRC='MB{link_program.VALUE}ME?AIMACTION=Submit1&ip_remote_user=EB{REMOTE_USER}EE&row2form_rec.VALUE=findmyrec_sub_login&sql_control=sql_lookup_a_user&enforce_color=ON' NAME='main'>");

and Replace it with this line:

	document.write("<FRAME SRC='MB{link_program.VALUE}ME?AIMACTION=vtasks&ip_remote_user=EB{REMOTE_USER}EE&db_table_name=MB{db_wb_table_name.VALUE}ME&wb_msg_status=Active&sort_titles1_menu=LFB{wb_msg_type.TITLE}LFE&error_template=finderror_msg.html' NAME='main'>");

NEXT

Search for this line:

	insertleaf(level1, buildleaf(2, "Support Resources","MB{link_program.VALUE}ME?AIMACTION=Resources1&ip_remote_user=EB{REMOTE_USER}EE"))

under the above line make a new line and paste this:

	insertleaf(level1, buildleaf(2, "View MB{aim_wb_variable.VALUE}ME?AIMACTION=vtasks&ip_remote_user=EB{REMOTE_USER}EE&db_ta ble_name.VALUE=MB{db_wb_table_name.VALUE}ME&wb_msg_status.VALUE=Active&sort_titles1_m enu.VALUE=LFB{wb_msg_type.TITLE}LFE&error_template=finderror_msg.html"))



*****u_navigation.html*****

Add the following code:

{View MB{aim_wb_variable.VALUE}ME*MB{link_program.VALUE}ME?AIMACTION=vtasks&ip_remote_user=EB{REMOTE_USER}EE&db_table_name.VALUE=MB{db_wb_table_name.VALUE}ME&wb_msg_status.VALUE=Active&error_template=finderror_msg.html*main}

