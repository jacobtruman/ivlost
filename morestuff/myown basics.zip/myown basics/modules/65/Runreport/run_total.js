<script language="JavaScript"><!--

var	loadtime;
function getloadtime()
{
        loadtime= new Date();
        loadtime=loadtime.getTime();
}
function getsubmittime()
{
	var	now;
	var	diff;
	var	min;
	var	sec;
	var	diffsec;
	var	totaltime;
	

        now= new Date();
        now=now.getTime();
	diff=now-loadtime;
	diffsec=diff/1000;
	diff=Math.round(diffsec);
	if(document.formname.running_total.value==""){
		document.formname.running_total.value=diffsec;
	}else{
		document.formname.running_total.value=Math.round(eval(document.formname.running_total.value)+eval(diffsec));
	}
	
	return 0;
}
// --></script></p>
