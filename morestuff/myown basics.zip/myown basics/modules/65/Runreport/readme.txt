****************************
*** Running Total Report ***
****************************

STEP 1:

Add the objects in the hd_obj.txt to your hd_obj file located under the

$IPHOME\client\config folder  ($IPHOME being the place that the HelpDesk software is installed.  Ex: c:\helpdesk)

Then search for the 'reports' object.
Add the following to the end of the 'VALUE':

^@report/running_total.html

Add the following to the end of the 'TITLE':

^@Running Total Report

NEXT search for the reports_show object.
Add the following to the 'NAME':

^@Running Total Report


STEP 2:

You will need to modify the s_submit.html and s_respond.html.  The modifications will be the same for both files, they are:

Add the following to the hidden fields:

<INPUT TYPE='hidden' NAME='running_total' VALUE='FB{running_total.VALUE}FE'>

You will need to add to the brules:
To the brules_load after placeFocus();

getloadtime();

To the brules_submit after the first '{'

getsubmittime();

You will also need to add the following Lib with the rest of the lib's:

LIBB{run_total.js}LIBE

STEP 3:

Copy the running_total.html to the $IPHOME\report folder

Copy the run_total.js to the $IPHOME\client\aimhtml\hd\lib folder

STEP 4:

Add a text field to the database called running_total