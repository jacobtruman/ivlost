********************************************
** Objects to be added in the hd_obj file **
********************************************

The objects in the hd_obj.txt file in the zip file have to be added in the hd_obj file.

Note: There are is an object in the hd_obj file which is related to the case number mapping.  It is the infotype-prefix object. You will need to modify this object to include the FAQ.
EXAMPLE:
FROM:

OBJECT{
	NAME=infotype-prefix
	VALUE=HD^$
	TYPE=MENU
	TITLE=Ticket^$
};

To:

OBJECT{
	NAME=infotype-prefix
	VALUE=HD^@FQ^$
	TYPE=MENU
	TITLE=Ticket^@FAQ^$
};

You will also need to add the following code to the enforce_fields object:

^@faq_status^@faq_question^@faq_answer

It should look like this when you are done:

};
OBJECT{
	NAME=enforce_fields
	VALUE=sub_access^@category^@sa_access^@sa_e_mail^@sa_login^@sa_permissions^@sub_e_mail^@sub_login^@sub_name^@problem^@short_desc^@status^@faq_status^@faq_question^@faq_answer^$
};

**************************
** Case_num file changes**
**************************

The entry you have made in the infotype-prefix object that entry has to be added in the case_num
file exactly the same way as in the infotype-prefix object and this is case sensitive, and
give it a starting number of your choice. For example you want the FAQ to start being numbered
from 2000 on you have to make an entry in the case_num file as FQ 2000.

*******************************************
** faq Table in the database **
*******************************************

The faq table has to be imported from the problem_track_faq.mdb to the default database in
the software. If helpdesk the database name is problem_track and may be different for the 
product purchased.

*******************************
** Changes to sp_states file **
*******************************

The entries in the sp_states.txt have to be added in the sp_states file.


*******************************
** Changes to up_states file **
*******************************

The entries in the up_states.txt have to be added in the up_states file.


************************************************
** Changes to be made in the navigation files **
************************************************

The code in the a_s_navigation.txt has to be added in the

$IPHOME\client\aimhtml\hd\staff\console\a_navigation.html and

$IPHOME\client\aimhtml\hd\staff\console\s_navigation.html 


The code in the s_vmain.txt has to be added in the

$IPHOME\client\aimhtml\hd\staff\console\s_vmain.html and

$IPHOME\client\aimhtml\hd\staff\console\s_frame.html 


The code in the u_navigation.txt has to be added to 

$IPHOME\client\aimhtml\hd\users\console\u_navigation.html


The code in the u_vmain.txt has to be added to 

$IPHOME\client\aimhtml\hd\users\console\u_vmain.html



**************************
** Folders to be copied **
**************************

The folder survey under the aimhtmlhduser folder has to be copied under the 

$IPHOME\client\aimhtml\hd\users folder and 

The folder survey under the aimhtmlhdstaff has to be copied under the

$IPHOME\client\aimhtml\hd\staff folder.


************************
** Files to be copied **
************************

Copy the finderror_faq.html to the

$IPHOME\client\aimhtml\hd folder

