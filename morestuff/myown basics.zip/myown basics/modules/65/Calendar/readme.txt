*************************************
*********  Calendar Module  *********
*************************************

Step 1:

Add the objects in the obj.txt to your hd_obj file.

The _cal_control object is where you set what object colors are determined by (Ex: status or priority).
For the _cal_color_code object, make sure that each of the items macth those in the object you selected in the _cal_control object Example: if you selected status for the _cal_control object then the VALUE of the _cal_color_code object would look something like this:

VALUE=item^@color^$Open^@blue^$Pending^@green^$Assigned^@red^$Closed^@purple^$

Step 2:

Add the states in the sp.txt to your sp_states file.

Step 3:

Add the link from the amenu.txt to your a_navigation.html and s_frame.html files.

Step 4:

copy the cal folder to the $IPHOME/client/aimhtml/hd/staff/ folder $IPHOME being the place you have the helpdesk installed (by default c:/helpdesk/)

Step 5:

Copy the calview.js to the $IPHOME/client/aimhtml/hd/lib/ folder