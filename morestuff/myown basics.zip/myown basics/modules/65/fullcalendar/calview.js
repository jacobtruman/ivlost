<script language='JavaScript'><!--
function doshow(lcolor,title,anc)
{
	document.write("<li>");
	document.write("<a href=\"MB{s_link_program.VALUE}ME?AIMACTION=RespondCal3&ip_remote_user=EB{REMOTE_USER}EE&row2form_rec.VALUE=act_case_num^$=="+anc+"^$&sql_control=sql_one_ticket_join_lookup_cal\" target=\"calbrowser\">");
        document.write("<font color=\""+lcolor+"\" size=\"1\" face=\"Verdana, Arial, Helvetica\">");
	document.write(title)
        document.write("</font>");
	document.write("</a>");


}

function dcell1()
{
	TB{TNB{_cal_md1}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell2()
{
	TB{TNB{_cal_md2}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell3()
{
	TB{TNB{_cal_md3}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell4()
{
	TB{TNB{_cal_md4}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell5()
{
	TB{TNB{_cal_md5}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell6()
{
	TB{TNB{_cal_md6}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell7()
{
	TB{TNB{_cal_md7}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}

function dcell8()
{
	TB{TNB{_cal_md8}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell9()
{
	TB{TNB{_cal_md9}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell10()
{
	TB{TNB{_cal_md10}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell11()
{
	TB{TNB{_cal_md11}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell12()
{
	TB{TNB{_cal_md12}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell13()
{
	TB{TNB{_cal_md13}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell14()
{
	TB{TNB{_cal_md14}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell15()
{
	TB{TNB{_cal_md15}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell16()
{
	TB{TNB{_cal_md16}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell17()
{
	TB{TNB{_cal_md17}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell18()
{
	TB{TNB{_cal_md18}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell19()
{
	TB{TNB{_cal_md19}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell20()
{
	TB{TNB{_cal_md20}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell21()
{
	TB{TNB{_cal_md21}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell22()
{
	TB{TNB{_cal_md22}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell23()
{
	TB{TNB{_cal_md23}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell24()
{
	TB{TNB{_cal_md24}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell25()
{
	TB{TNB{_cal_md25}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell26()
{
	TB{TNB{_cal_md26}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell27()
{
	TB{TNB{_cal_md27}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell28()
{
	TB{TNB{_cal_md28}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell29()
{
	TB{TNB{_cal_md29}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell30()
{
	TB{TNB{_cal_md30}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell31()
{
	TB{TNB{_cal_md31}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell32()
{
	TB{TNB{_cal_md32}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell33()
{
	TB{TNB{_cal_md33}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell34()
{
	TB{TNB{_cal_md34}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell35()
{
	TB{TNB{_cal_md35}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell36()
{
	TB{TNB{_cal_md36}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell37()
{
	TB{TNB{_cal_md37}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell38()
{
	TB{TNB{_cal_md38}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}

function dcell39()
{
	TB{TNB{_cal_md39}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell40()
{
	TB{TNB{_cal_md40}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell41()
{
	TB{TNB{_cal_md41}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
function dcell42()
{
	TB{TNB{_cal_md42}TNE
		doshow("CB{_cal_color}CE","CB{act_category}CE"+" : "+"CB{act_owner}CE"+" : "+"CB{act_status}CE","CB{act_case_num}CE");
	}TE
}
// --></script>