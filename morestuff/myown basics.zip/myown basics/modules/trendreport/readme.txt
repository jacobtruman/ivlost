###########################################
## Changes To be made to the hd_obj file ##
###########################################

To implement the trend report in the Existing system you have to add the following object to the
reports object in the hd_obj file or the Configuration Tool.

You have to modify the hd_obj file and modify the reports object to read as follows:

The default report object will be as follows:

OBJECT{
	NAME=reports
	VALUE=report/percent_report.html^@report/percent_today.html^@report/Summary_Report.html^@report/Work_Order_Report.html^@report/Time_Elapsed_Report.html^$
	CONTROL=SYSTEM
	TYPE=MENU
	TITLE=Percentage Report^@Activities For Today^@Summary Report^@Full Workorder^@Elapsed Time Report^$
};

You need to add the following in the VALUE field report/trend_report.html 
and in the TITLE you need to add  Trend Report.

After the modification the object would look like this:

OBJECT{
	NAME=reports
	VALUE=report/percent_report.html^@report/percent_today.html^@report/Summary_Report.html^@report/Work_Order_Report.html^@report/Time_Elapsed_Report.html^@report/trend_report.html^$
	CONTROL=SYSTEM
	TYPE=MENU
	TITLE=Percentage Report^@Activities For Today^@Summary Report^@Full Workorder^@Elapsed Time Report^@Trend Report^$
};

Then you need to edit the reports_show object to add the Trend Report to appear in the menu.

The default object before modification is as follows:

OBJECT{
	NAME=reports_show
	CONTROL=SYSTEM
	TYPE=MENU
	TITLE=Percentage Report^@Summary Report^@Full Workorder^@Elapsed Time Report^$
};

After the Modification the object should look like this:

OBJECT{
	NAME=reports_show
	CONTROL=SYSTEM
	TYPE=MENU
	TITLE=Percentage Report^@Summary Report^@Full Workorder^@Elapsed Time Report^@Trend Report^$
};

Then you need to add a new object in the hd_obj file. The object is as follows:

OBJECT{
	NAME=trend_report_fields
	VALUE=status^@assigned_to^$category^@assigned_to^$category^@priority_type^$assigned_to^@date_open^$
};


###########################
## Template to be copied ##
###########################

You have to copy the trend_report.html to the report folder under the $IPHOME.

