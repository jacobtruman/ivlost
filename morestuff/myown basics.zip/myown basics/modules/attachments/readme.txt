********************************************
** Objects to be added in the hd_obj file **
********************************************

The objects in the hdobjfile.txt have to be added in the hd_obj file. Make sure that the 
attachdir and the pre_attachdir is pointing to the correct location. Also please ask the 
customer to create a new folder under the $IPWEB folder called attachments and have change
permissions to that folder. Where $IPWEB is the name of the folder under the webserver 

For example : c:/inetpub/wwwroot/helpdesk/attachments on NT

*******************************************
** Changes to be made on the submit form **
*******************************************

The code in the submitform.txt has to be added in the 

$IPHOME\client\aimhtml\staff\submit\s_submit.html and 

$IPHOME\client\aimhtml\users\submit\u_submit.html

This code has to be added after code for the Submit button on both the forms.

Also in the same templates you have to modify the form tag and add enctype="multipart/form-data".

Before Changes:

<form action="MB{s_link_program.VALUE}ME" method="POST" name="submitform" onsubmit="return check_checkbox();">


After Changes:

<form action="MB{s_link_program.VALUE}ME" method="POST" enctype="multipart/form-data" name="submitform" onsubmit="return check_checkbox();">

*********************************************
** Changes to be made on the respond forms **
*********************************************

The code in the repondform.txt has to be added in the 

$IPHOME\client\aimhtml\staff\respond\s_respond.html and 

$IPHOME\client\aimhtml\users\update\u_escalate.html

This code has to be added in both the respond forms after the  code for the Update/Respond Button.


Also in the same templates you have to modify the form tag and add enctype="multipart/form-data".

Before Changes:

<form action="MB{s_link_program.VALUE}ME" method="POST" name="submitform" onsubmit="return check_checkbox();">


After Changes:

<form action="MB{s_link_program.VALUE}ME" method="POST" enctype="multipart/form-data" name="submitform" onsubmit="return check_checkbox();">

**********************************************
** Changes to be made to the view templates **
**********************************************

The code in the viewform.txt has to be added in the 

$IPHOME\client\aimhtml\staff\viewcase\s_viewcase.html and 

$IPHOME\client\aimhtml\users\viewcase\u_viewcase.html

This code has to be added at the end or the viewcase templates.

NOTE: ALL THE ABOVE CODE MUST BE ADDED WITHIN THE <form> and </form> TAGS IN EVERY TEMPLATE.

  