~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

~~ Auto Assign Rule based of off a field in the users table in the database ~~

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

STEP 1:

You have to open the u_vmain.html in any text editor and search for this line:

insertleaf(level1, buildleaf(2, "Submit Ticket","MB{link_program.VALUE}ME?AIMACTION=Submit&ip_remote_user=EB{REMOTE_USER}EE&row2form_rec.VALUE=findmyrec_sub_login&sql_control=sql_lookup_a_user"))

you will have to add the following code to this line:

&sub.VALUE=ODB{sub_dept.VALUE}ODE

After the modification the line would look something like this.

Ticket","MB{link_program.VALUE}ME?AIMACTION=Submit&ip_remote_user=EB{REMOTE_USER}EE&sub.VALUE=ODB{sub_dept.VALUE}ODE&row2form_rec.VALUE=findmyrec_sub_login&sql_control=sql_lookup_a_user"))

Save the file.

NOTE: This file should not be opened in frontpage.

STEP 2:

You have to open the u_submit.html in any text editor such as notepad and add the following line:

<input type="hidden" name="sub_dept.VALUE" value="ODB{sub.VALUE}ODE">

in the hidden field section of the template.

Save the file and test the changes.


STEP 3:

In the staff side open the helpdesk\client\aimhtml\hd\staff\s_findprofilesubmitres.html

and add the following line along with the other hidden fields,

<input type="hidden" name="sub_dept.VALUE" value="CB{sub_dept}CE">

STEP 4:

Open the helpdesk\client\aimhtml\hd\staff\s_submit.html and add the following line alog with the other hidden field.

<input type="hidden" name="sub_dept.VALUE" value="ODB{sub_dept.VALUE}ODE">


Save the files.