*********************************************************
Changes to be made to the s_vmain.html
*********************************************************
STEP 1:

Add the following Javascript to the s_vmain.html, after the <body>

<script language="JavaScript"><!--

var user="EB{REMOTE_USER}EE";
var list="FB{restrict_admin_menu.VALUE}FE";
var b=0;
var r;
var	item;
var i;
	r = list.indexOf("^$", b);
	list = list.substring(0,r);
	b=0;
	for (i = 0; b<list.length; i++) {
				
             r = list.indexOf("^@", b);
				 if(r==-1){
						
						r=list.length;
				 }
				
			    item = list.substring(b, r); 
				
				 if(item==user){
					
 window.location="MB{s_link_program.VALUE}ME?AIMACTION=gotoadminconsole&amp;ip_remote_user=EB{REMOTE_USER}EE&skey=919236391910632690&ip_remote_user=EB{REMOTE_USER}EE";
						break;
				 }
              
              b = r + 2; 
					
   }
// --></script></font><br>
</p>


STEP 2:

Save the file


*********************************************
CHANGES TO BE MADE TO EVERY TEMPLATE
*********************************************

If you open everytemplate you have to replace the existing back button code with the following:
 
<table border="0" cellspacing="1">
    <tr>
        <td><a
        href="MB{s_link_program.VALUE}ME?AIMACTION=backbutton&amp;amp;ip_remote_user=EB{REMOTE_USER}EE&amp;sqlquery1=query_get_active_admin_login_tasks"
        target="_top"><img src="MB{picsdir.VALUE}MEhome.gif"
        border="0" width="23" height="22"></a></td>
        <td><a
        href="MB{s_link_program.VALUE}ME?AIMACTION=backbutton&amp;amp;ip_remote_user=EB{REMOTE_USER}EE&amp;sqlquery1=query_get_active_admin_login_tasks"
        target="_top"><font size="2"
        face="Verdana, Arial, Helvetica"><strong>Click Here to
        Return to the Tasks</strong></font></a></td>
    </tr>
</table>

The new query being added is the following:

sqlquery1=query_get_active_admin_login_tasks.


********************************************************
CHANGES TO BE MADE TO THE hd_obj file 
********************************************************

Open the hd_obj file and add the following code in there:

OBJECT{
	NAME=query_get_active_admin_login_tasks
	VALUE=menulist_restrict_admin_menu=select sa_login from staff where ((sa_permissions='admin') and (sa_access = 'active')) order by sa_login
};

Save the file.
