~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

~~ Auto Assign Rule based of off a field in the users table in the database ~~

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

STEP 1:

You have to open the u_vmain.html in any text editor and search for this line:

insertleaf(level1, buildleaf(2, "Submit Ticket","MB{link_program.VALUE}ME?AIMACTION=Submit&ip_remote_user=EB{REMOTE_USER}EE&row2form_rec.VALUE=findmyrec_sub_login&sql_control=sql_lookup_a_user"))

you will have to add the following code to this line:

&sub.VALUE=ODB{sub_dept.VALUE}ODE

After the modification the line would look something like this.

Ticket","MB{link_program.VALUE}ME?AIMACTION=Submit&ip_remote_user=EB{REMOTE_USER}EE&sub.VALUE=ODB{sub_dept.VALUE}ODE&row2form_rec.VALUE=findmyrec_sub_login&sql_control=sql_lookup_a_user"))

Save the file.

NOTE: This file should not be opened in frontpage.

STEP 2:

You have to open the u_submit.html in any text editor such as notepad and add the following line:

<input type="hidden" name="sub_dept.VALUE" value="ODB{sub.VALUE}ODE">

in the hidden field section of the template.

Save the file and test the changes.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

~~ If the you are using a system which has back button links on every template on the users side for example in the Helpdesk    for Customer service.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

You have to add the following lines in the backbutton links.

BY DEFAULT THE BACK BUTTON LINK IS AS FOLLOWS:
------------------------------------------------

<table border="0" cellspacing="1">
    <tr>
         <td>
            <a href="MB{link_program.VALUE}ME?AIMACTION=backbutton&amp;amp;ip_remote_user=EB{REMOTE_USER}EE">
            <img src="MB{picsdir.VALUE}MEhome.gif" border="0" width="23" height="22">
            </a>
         </td>
         <td>
           <a href="MB{link_program.VALUE}ME?AIMACTION=backbutton&amp;amp;ip_remote_user=EB{REMOTE_USER}EE">
           <font size="2" face="Verdana, Arial, Helvetica"><strong>Click
         Here to Return to the Customer Tasks</strong>
           </font>
           </a>
         </td>
    </tr>
</table>


The code you need to add is:
----------------------------


row2form_rec.VALUE=sub_login^$==EB{REMOTE_USER}EE^$
sql_control=sql_lookup_a_user


AFTER MODIFICATION THE CODE IS:
-------------------------------

<table border="0" cellspacing="1">
    <tr>
         <td>
            <a href="MB{link_program.VALUE}ME?AIMACTION=backbutton&amp;amp;ip_remote_user=EB{REMOTE_USER}EE&row2form_rec.VALUE=sub_login^$==EB{REMOTE_USER}EE^$&sql_control=sql_lookup_a_user">
            <img src="MB{picsdir.VALUE}MEhome.gif" border="0" width="23" height="22">
            </a>
         </td>
         <td>
           <a href="MB{link_program.VALUE}ME?AIMACTION=backbutton&amp;amp;ip_remote_user=EB{REMOTE_USER}EE&row2form_rec.VALUE=sub_login^$==EB{REMOTE_USER}EE^$&sql_control=sql_lookup_a_user">
           <font size="2" face="Verdana, Arial, Helvetica"><strong>Click
         Here to Return to the Customer Tasks</strong>
           </font>
           </a>
         </td>
    </tr>
</table>


Save the file.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

~~ Changes to be made to the up_states file ~~

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Open the up_states file in any text editor such as notepad and search for backbotton and change the line from:

backbutton=up_startup users/console/u_vmain.html

TO:

backbutton=up_row2form users/console/u_vmain.html

Save the file and test the changes.



~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~