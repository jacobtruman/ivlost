
*****************************************************************************************
To implement the feature when a staff reponds to a ticket you could assign the ticket to a particular staff.

*****************************************************************************************

If you want to have this feature to be implemented when a staff responds to a ticket.
You have to make modifications to two templates and the code would be different this time.

STEP 1:

Open the s_findrespondres.html in the helpdesk\client\aimhtml\hd\staff\respond folder and search for this code:
<a href="MB{s_link_program.VALUE}ME?AIMACTION=row2form&amp;ip_remote_user=EB{REMOTE_USER}EE&amp;row2form_rec.VALUE=case_num^$==CB{case_num}CE^$">

In this code you have to add the following code at the end after the $ (With out a space):

&sqlquery1=query_get_all_staff_login_by_sa_login

After modification the line would look like this:

<a href="MB{s_link_program.VALUE}ME?AIMACTION=row2form&amp;ip_remote_user=EB{REMOTE_USER}EE&amp;row2form_rec.VALUE=case_num^$==CB{case_num}CE^$&sqlquery1=query_get_all_staff_login_by_sa_login">

Save the file. 

STEP 2:

Open the s_respond.html and add the following code to where ever you want the field to appear:

<tr>
            <td bgcolor="#FFFFFF"><font color="#000000" size="2"
            face="Verdana, Arial, Helvetica"><b>MB{assigned_to.TITLE}ME</b></font></td>
            <td bgcolor="#FFFFFF"><font color="#000000" size="2"
            face="Verdana, Arial, Helvetica"><select
            name="VB{assigned_to.VALUE}VE" size="1">
                <option>DB{sa_login.VALUE}DE</option>
                <option selected>ODB{assigned_to.VALUE}ODE</option>
            </select></font></td>
        </tr>


Save the file and test the changes.
