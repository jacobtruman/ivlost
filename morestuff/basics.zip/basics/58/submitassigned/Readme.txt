To implement the feature where the staff could assign the ticket during the time of submmission.


STEP 1:

Open the sp_states file in notepad and search for this line:

Select User=up_startup staff/submit/s_submit.html -as

You need to change this line to look like this:

Select User=up_gsql staff/submit/s_submit.html -as

Save the file.

STEP 2:

Open the s_submit.html template and add the below code where ever you want it to appear.

 

<tr>
            <td bgcolor="#FFFFFF"><font color="#000000" size="2"
            face="Verdana, Arial, Helvetica"><b>MB{assigned_to.TITLE}ME</b></font></td>
            <td bgcolor="#FFFFFF"><font color="#000000" size="2"
            face="Verdana, Arial, Helvetica"><select
            name="VB{assigned_to.VALUE}VE" size="1">
                <option selected>nobody</option>
                <option>DB{assigned_to.VALUE}DE</option>
            </select></font></td>
        </tr>

Save the template.

STEP 3:

Open the s_findprofilsubmitres.html in notepad and include the below code in the hidden field area.

<input type="hidden" name="sqlquery1" value="query_get_active_staff_login">

Save the file and test the changes.

NOTE: You have to assign the Ticket during the time of submission or else the system will not allow
you to submit a ticket as it is one of the mandatory field in the system.

Also you could get rid of the "Assign Tickets to me" piece of code, which is follows as your name
would appear in the dropdown list.

The code you need to delete is:

<tr>
            <td colspan="2"><input type="checkbox"
            name="select_staff" value="ON"><font color="#000000"
            size="2" face="Verdana, Arial, Helvetica"><b>Assign
            Ticket To Me</b></font></td>
        </tr>

###################################################################################################

To implement this feature when a staff reponds to a ticket.

If you want to have this feature to be implemented when a staff responds to a ticket.
You have to make modifications to two templates and the code would be different this time.

STEP 1:

Open the s_findrespondres.html in the helpdesk\client\aimhtml\hd\staff\respond folder and search for this code:
<a href="MB{s_link_program.VALUE}ME?AIMACTION=row2form&amp;ip_remote_user=EB{REMOTE_USER}EE&amp;row2form_rec.VALUE=case_num^$==CB{case_num}CE^$">

In this code you have to add the following code at the end after the $ (With out a space):

&sqlquery1=query_get_all_staff_login_by_sa_login

After modification the line would look like this:

<a href="MB{s_link_program.VALUE}ME?AIMACTION=row2form&amp;ip_remote_user=EB{REMOTE_USER}EE&amp;row2form_rec.VALUE=case_num^$==CB{case_num}CE^$&sqlquery1=query_get_all_staff_login_by_sa_login">

Save the file. 

STEP 2:

Open the s_respond.html and add the following code to where ever you want the field to appear:

<tr>
            <td bgcolor="#FFFFFF"><font color="#000000" size="2"
            face="Verdana, Arial, Helvetica"><b>MB{assigned_to.TITLE}ME</b></font></td>
            <td bgcolor="#FFFFFF"><font color="#000000" size="2"
            face="Verdana, Arial, Helvetica"><select
            name="VB{assigned_to.VALUE}VE" size="1">
                <option>DB{sa_login.VALUE}DE</option>
                <option selected>ODB{assigned_to.VALUE}ODE</option>
            </select></font></td>
        </tr>


Save the file and test the changes.


