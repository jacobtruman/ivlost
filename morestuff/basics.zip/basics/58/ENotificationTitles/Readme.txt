This note will explain to you as to how you will see the Email Notification rules set.

STEP 1: Rename the IPHOME\client\config folder. (Where IPHOME is the place where you have installed the software, by default it is c:\helpdesk).

STEP 2: Copy the admin_states file from the zip file to the IPHOME\client\config folder.

STEP 3: copy the list_notification.html file from the zip file to the IPHOME\client\aimhtml\admin\mailnotification\folder.

STEP 4: Copy the aimadmin.exe to your scripts/cgi-bin folder by default it is c:\inetpub\scripts on NT.


STEP 5: Test the changes.