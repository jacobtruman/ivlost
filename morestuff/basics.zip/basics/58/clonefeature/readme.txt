**********************************
**        CLONE FEATURE         **
**********************************


STEP 1:
-------

Open the IPHOME\client\config\sp_states file and the following in there:

# Clone Ticket - /staff/clone
Clone=up_startup staff/clone/s_findticketclone.html
Find Ticket(s) to Clone=up_find staff/clone/s_findcloneres.html
row2form_clone=up_row2form staff/clone/s_submitclone.html

STEP 2:
-------

Copy the clone folder under the IPHOME\client\aimhtml\hd\staff folder.

STEP 4:
-------


Open the IPHOME\client\config\hd_obj file and add the following query in there:

OBJECT{
	NAME=query_get_all_user
	VALUE=menulist_sub_login_list=select sub_login from users order by sub_login
};

STEP 5: 
-------

Open the IPHOME\client\aimhtml\hd\staff\console\s_vmain.html and a_vmain.html and add the following lines:

insertleaf(level1, buildleaf(2, "Clone Ticket(s)","MB{s_link_program.VALUE}ME?AIMACTION=Clone&ip_remote_user=EB{REMOTE_USER}EE&sqlquery1=query_get_all_staff_login"))					
