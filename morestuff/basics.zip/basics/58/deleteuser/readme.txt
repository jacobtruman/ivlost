
*****************************************************************
To Add the Option where you need to Delete a User through the GUI
*****************************************************************

Change to be made to the console file.
---------------------------------------


Open the a_vmain.html and search for Change password and go to the end of the line and hit enter and at the beginning of the
new line add this code:

insertleaf(level1, buildleaf(2, "Delete User(s)","MB{s_link_program.VALUE}ME?AIMACTION=DeleteUser&ip_remote_user=EB{REMOTE_USER}EE&sqlquery1=query_get_all_user_login"))



Changes to be made the sp_states file.
--------------------------------------

Open the sp_states file and add the following code:

################### Delete User ########################

DeleteUser=up_gsql staff/delete/s_finduserdelete.html
Delete User(s)=up_confirmprint staff/delete/s_userdelete.html
Confirm Deletion of User(s)=up_delete staff/delete/s_userdeleteres.html
Find User(s) to Delete=up_find staff/delete/s_finduserdeleteres.html


Copying the Files.
-------------------

Please copy "FILES" only to the delete folder,under the helpdesk\client\aimhtml\hd\staff\delete folder.

