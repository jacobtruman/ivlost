This note will explain to you as to how you would implement the XLT report in the version 5.8 version.

STEP 1:

Under the IPWEB (by default inetpub\wwwroot\helpdesk) create a new folder called XLT. 

STEP 2: 

Make sure that IUSER_YOURMACHINE name user has full control to this folder.

STEP 3:

Copy the xltreport.xlt to the new folder you created.

STEP 5:

*******************************************
** CHANGE TO BE MADE TO THE CONSOLE FILE **
*******************************************

Open the C:\helpdesk\client\aimhtml\hd\staff\console\a_vmain.html file using any text editor such as notepad and search for Reports.

Add the following line along with the other code in there:

insertleaf(level1, buildleaf(2, "Excel Reports","MB{s_link_program.VALUE}ME?AIMACTION=DataMining1&ip_remote_user=EB{REMOTE_USER}EE&sqlquery1=query_get_all_staff_login"))

Save the file.

STEP 6:

*******************************************
** CHANGES TO BE MADE TO THE STATES FILE **
*******************************************

Open the C:\helpdesk\client\config\sp_states file using any text editor such as notepad and and add the below code anywhere in the system.

################### Data Mining ###############################
#Data mining
DataMining1=up_gsql staff/reports/s_xltreports.html
Create Excel Report=up_wxlt staff/reports/dataminingres.html staff/reports/datamining_export.html
getxltdata=up_gxlt

STEP 7:

****************************
** TEMPLATES TO BE COPIED **
****************************

Go to your /helpdesk/client/aimhtml/hd/staff/reports/ and copy the s_xltreports.html and the dataminingres.html from the zip file.

STEP 8:

************************
** Image to be copied **
************************

Copy the xlt_macros.gif into the inetpub/wwwroot/helpdesk/pics/ folder.


