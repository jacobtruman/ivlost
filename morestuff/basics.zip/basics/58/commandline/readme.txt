How to Use up_add command to add tickets from command line

usage: up_add template_name file

Example:

Step 1: Set your variable IPHOME, IPHOME is the directory path where the software is installed.

IPHOME=/home/helpdesk;export IPHOME

Step 2: Execute the command as shown,

 up_add users/submit/submitres.html /tmp/addin

the format of the file addin is as shown below

dbkey1^@dbkey2....^@dbkeyn^$value1^@value2...^@valuen^$

Make sure that the file /tmp/addin has all the fields that you have enforced.
If you miss a field then the ticket will not be submitted.


Example for the /tmp/addin file is the file name inputexample attached in this zip file:

submitted_by^@category^@short_desc^@problem^@status^$user1^@Printing^@Test^@Test^@Open^$
