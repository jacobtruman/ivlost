To implement the feature where the staff could assign the ticket during the time of submmission.


STEP 1:

Open the s_submit.html template and add the below code where ever you want it to appear.

 

<tr>
            <td bgcolor="#FFFFFF"><b><font color="#000000" face="Verdana, Arial,  Helvetica" size="1">MB{assigned_to.TITLE}ME</font></b></td>
            <td bgcolor="#FFFFFF"><font color="#000000" size="2"
            face="Verdana, Arial, Helvetica"><select
            name="assigned_to" size="1" class="formfield">
                <option selected>nobody</option>
                <option>DB{assigned_to.VALUE}DE</option>
            </select></font></td>
        </tr>


Save the template.

STEP 2:

Open the s_findprofilsubmitres.html in notepad and include the below code in the hidden field area.

<input type="hidden" name="sqlquery1" value="query_get_active_staff_login">

Save the file and test the changes.

NOTE: You have to assign the Ticket during the time of submission or else the system will not allow you to submit a ticket as it is one of the mandatory field in the system.

Also you could get rid of the "Assign Tickets to me" piece of code, which is follows as your name
would appear in the dropdown list.

The code you need to delete is:

 <TR>
            <TD COLSPAN='2' HEIGHT='15'>	
            	<FONT FACE="Verdana, Arial, Helvetica" SIZE='1'>
            		<INPUT TYPE='checkbox' NAME='select_staff' VALUE='ON'>
            			<B>
                 		Assign MB{aim_ticket_variable.VALUE}ME To Me
            			</B>
            		</FONT>
            	</TD>
        </TR>
						

STEP 3:

IN the s_submit.html template modify the function brules_submit() as follow:

Before modification:
----------------------

function brules_submit()
{
	var	r;
	r= enforce();
	if(r==true){
		r=checktime();
		if(r==true){
			check_checkbox();
			return (true);
		}else{
			return (false);
		}
	}else{
		return (false);
	}
}

AFTER MODIFICATION:
---------------------

function brules_submit()
{
	var	r;
	r= enforce();
	if(r==true){
		r=checktime();
		if(r==true){
			
			return (true);
		}else{
			return (false);
		}
	}
}

Save the file.
###################################################################################################

To implement this feature when a staff reponds to a ticket.

If you want to have this feature to be implemented when a staff responds to a ticket.
You have to make modifications to two templates and the code would be different this time.

STEP 1:

Open the s_findrespondres.html in the helpdesk\client\aimhtml\hd\staff\respond folder and search for this code:
<a href="MB{s_link_program.VALUE}ME?AIMACTION=row2form&amp;ip_remote_user=EB{REMOTE_USER}EE&amp;row2form_rec.VALUE=case_num^$==CB{case_num}CE^$">

In this code you have to add the following code at the end after the $ (With out a space):

&sqlquery1=query_get_active_staff_login_toassign


After modification the line would look like this:

<a href="MB{s_link_program.VALUE}ME?AIMACTION=row2form&amp;ip_remote_user=EB{REMOTE_USER}EE&amp;row2form_rec.VALUE=case_num^$==CB{case_num}CE^$&sqlquery1=query_get_all_staff_login_by_sa_login">

Save the file. 

STEP 2:

Open the s_respond.html and add the following code to where ever you want the field to appear:

<tr>
            <td><font color="#000000" size="1"
            face="Verdana, Arial, Helvetica"><b>MB{assigned_to.TITLE}ME</b></font></td>
            <td><font size="1" face="Verdana, Arial, Helvetica"><strong>Was:
            </strong></font><a
            href="MB{s_link_program.VALUE}ME?AIMACTION=ViewStaff&ip_remote_user=EB{REMOTE_USER}EE&row2form_rec.VALUE=sa_login^$==FB{assigned_to.VALUE}FE^$&sql_control=sql_lookup_a_staff"><font
            size="1" face="Verdana, Arial, Helvetica"><strong>FB{assigned_to.VALUE}FE</strong></font></a><font
            size="1" face="Verdana, Arial, Helvetica"><strong>
            Will be:</strong></font><font color="#000000"
            size="2" face="Verdana, Arial, Helvetica"><select
            name="assigned_to" size="1" class="formfield">
                <option selected>ODB{assigned_to.VALUE}ODE</option>
                <option>DB{staff_menu.VALUE}DE</option>
              </select></font></td>
        </tr>

Save the file and test the changes.


