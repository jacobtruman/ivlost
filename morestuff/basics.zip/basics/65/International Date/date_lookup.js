<IFRAME STYLE="display:none;position:absolute;width:148;height:194;z-index=100" ID="CalFrame" MARGINHEIGHT=0 MARGINWIDTH=0 NORESIZE FRAMEBORDER=0 SCROLLING=NO SRC="MB{link_program.VALUE}ME?AIMACTION=htmlcal&ip_remote_user=EB{REMOTE_USER}EE"></IFRAME>
<SCRIPT LANGUAGE="javascript" SRC="MB{ipweb_path.VALUE}ME/datepicker/calendar.js"></SCRIPT>
<SCRIPT FOR=document EVENT="onclick()">
<!--
document.all.CalFrame.style.display="none";
//-->
</SCRIPT>

<script language="JavaScript"><!--
globalipwebpath="MB{ipweb_path.VALUE}ME";
function changedate(menu,fieldname)
{
	var sel;
	var	val;
	var	r;
	
	sel = menu.selectedIndex;
 	val=menu.options[sel].text;
	r=val.indexOf(":",0);
	if(r==-1){
			;
	}else{
		val=val.substring(r+2,val.length);
	}
	fieldname.value=val;
	menu.selectedIndex=0;
}

function create_date(fieldname)
{
			  var	todat_str;
			  var	yesterday_str;
			  var	thisweek_str;
			  var	lastweek_str;
			  var	thismonth_str;
			  var	lastmonth_str;
			  var	str;

			  today_str=calcdate("today",0);
			  yesterday_str=calcdate("yesterday",0);
			  thisweek_str=calcdate("thisweek",0);
			  lastweek_str=calcdate("lastweek",0);
			  thismonth_str=calcdate("thismonth",0);
			  lastmonth_str=calcdate("lastmonth",0);
			  
				
		           document.write("<select class=formfield name=");
			  document.write(fieldname+fieldname);
			  document.write(" size=\"1\""); 
			  document.write("onchange=changedate(this,"+fieldname+")> ");
			  document.write("<option></option>");

			  document.write("<option ");
			  document.write("value=\""+today_str+"\">");
			  document.write("Today: "+today_str);
			  document.write("</option>");
			
			   document.write("<option ");
			  document.write("value=\""+yesterday_str+"\">");
			  document.write("Yesterday: "+yesterday_str);
			  document.write("</option>");
	
			   document.write("<option ");
			  document.write("value=\""+thisweek_str+"\">");
			  document.write("This Week: "+thisweek_str);
			  document.write("</option>");

			   document.write("<option ");
			  document.write("value=\""+lastweek_str+"\">");
			  document.write("Last Week : "+lastweek_str);
			  document.write("</option>");

			  document.write("<option ");
			  document.write("value=\""+thismonth_str+"\">");
			  document.write("This Month: "+thismonth_str);
			  document.write("</option>");

			  document.write("<option ");
			  document.write("value=\""+lastmonth_str+"\">");
			  document.write("Last Month: "+lastmonth_str);
			  document.write("</option>");
		          document.write("</select>");
document.write("<br><font color=\"#000000\" size=\"-2\" face=\"Verdana, Arial, Helvetica\"><b>Or By Typing In A Date Range (Format: mm/dd/yyyy--mm/dd/yyyy)</b></font>");

}

function calcyear(year)
{
	if(year<100){
		year="19" + year;
	}else{
		if(year<200){
			year+=1900;
		}
	}
	return(year);
	
}
function calcdate(op,day)
{
        var today;
        var     today_day;
        var     today_weekday;
        var     today_month;
        var     today_year;
        var     today_inms;

        var     calc;
        var     calc_day;
        var     calc_weekday;
        var     calc_month;
        var     calc_year;
        var     calc_inms;

        var     ret;
        var     start;
        var     end;
        var     adjust;


        today= new Date();
        today_inms=today.getTime();
        today_weekday=today.getDay();
        today_day=today.getDate();
        today_month=today.getMonth()+1;
        today_year=calcyear(today.getYear());

        if(op=="thisweek"){
                if(today_weekday==0){
                	adjust=0;
                }else{
                        adjust=7-today_weekday;
                }
                calc_inms=today_inms+(60*60*24*adjust*1000);
                calc=new Date(calc_inms);
                calc_day=calc.getDate();
                calc_month=calc.getMonth()+1;
                calc_year=calcyear(calc.getYear());
                end=calc_day+"/"+calc_month+"/"+calc_year;

                if(today_weekday==0){
                	adjust=6;
                }else{
                        adjust=today_weekday-1;
                }
                calc_inms=today_inms-(60*60*24*adjust*1000);
                calc=new Date(calc_inms);
                calc_day=calc.getDate();
                calc_month=calc.getMonth()+1;
                calc_year=calcyear(calc.getYear());
                start=calc_day+"/"+calc_month+"/"+calc_year;
                ret=start+"--"+end;
                return (ret);
        }else if(op=="today"){
                start=today_day+"/"+today_month+"/"+today_year;
                ret=start;
                return (ret);
        }else if(op=="yesterday"){
                adjust=1;
                calc_inms=today_inms-(60*60*24*adjust*1000);
                calc=new Date(calc_inms);
                calc_day=calc.getDate();
                calc_month=calc.getMonth()+1;
                calc_year=calcyear(calc.getYear());
                start=calc_day+"/"+calc_month+"/"+calc_year;
                ret=start;
                return (ret);
        }else if(op=="lastweek"){
                if(today_weekday==0){
                        adjust=7;
                }else{
                        adjust=today_weekday;
                }
                calc_inms=today_inms-(60*60*24*adjust*1000);
                calc=new Date(calc_inms);
                calc_day=calc.getDate();
                calc_month=calc.getMonth()+1;
                calc_year=calcyear(calc.getYear());
                end=calc_day+"/"+calc_month+"/"+calc_year;

                adjust=adjust+6;
                calc_inms=today_inms-(60*60*24*adjust*1000);
                calc=new Date(calc_inms);
                calc_day=calc.getDate();
                calc_month=calc.getMonth()+1;
                calc_year=calcyear(calc.getYear());
                start=calc_day+"/"+calc_month+"/"+calc_year;

                ret=start+"--"+end;
                return (ret);
        }else if(op=="thismonth"){
                end=today_day+"/"+today_month+"/"+today_year;
                start="1"+"/"+today_month+"/"+today_year;
                ret=start+"--"+end;
                return (ret);
        }else if(op=="lastmonth"){
                adjust=today_day;
                calc_inms=today_inms-(60*60*24*adjust*1000);
                calc=new Date(calc_inms);
                calc_day=calc.getDate();
                calc_month=calc.getMonth()+1;
                calc_year=calcyear(calc.getYear());
                end=calc_day+"/"+calc_month+"/"+calc_year;

                start="1"+"/"+calc_month+"/"+calc_year;

                ret=start+"--"+end;
                return (ret);
        }else if(op=="lastbyday"){
                end=today_day+"/"+today_month+"/"+today_year;

                calc_inms=today_inms-(60*60*24*day*1000);
                calc=new Date(calc_inms);
                calc_day=calc.getDate();
                calc_month=calc.getMonth()+1;
                calc_year=calcyear(calc.getYear());
                start=calc_day+"/"+calc_month+"/"+calc_year;

                ret=start+"--"+end;
                return (ret);
        }else{
                return (ret);
        }       

        
}
// --></script>
<script language="JavaScript"><!--
function calshow(fieldname)
{

if (navigator.appName == "Netscape") {

		;
} else {
                writecallink(fieldname);
}


}
function writecallink(fieldname)
{
   var	str="<A href=\"javascript:ShowCalendar(document.formname.dimg"+fieldname+",document.formname."+fieldname+",null, 'EB{TODAY}EE', '12/32/2099')\" onclick=event.cancelBubble=true;><IMG align=top border=0 height=21 id=dimg"+fieldname+ " src=\"MB{ipweb_path.VALUE}MEdatepicker/calendar.gif\" style=\"POSITION: relative\" width=34></A>"
   document.write(str);
}
// --></script>
