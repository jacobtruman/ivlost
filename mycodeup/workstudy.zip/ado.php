<?php
// ado.inc.php
   
   $ADO_NUM = 1;
   $ADO_ASSOC = 2;
   $ADO_BOTH = 3;
   
   function ado_connect( $dsn )
   {
       $link = new COM("ADODB.Connection");
       $link->Open("DRIVER={Microsoft Access Driver (*.mdb)}; DBQ=$dsn");
       return $link;
   }
   
   function ado_close( $link )
   {
       $link->Close();
   }
   
   function ado_num_fields( $res )
   {
       return $res->Fields->Count;
   }
   
   function ado_error($link)
   {
       return $link->Errors[$link->Errors->Count-1]->Number;
   }
   
   function ado_errormsg($link)
   {
       return $link->Errors[$link->Errors->Count-1]->Description;
   }
   
   function ado_fetch_array( $res, $result_type,  $row_number = -1 )
   {
       global $ADO_NUM, $ADO_ASSOC, $ADO_BOTH;
       if( $row_number > -1 ) // Defined in adoint.h - adBookmarkFirst    = 1
           $res->Move( $row_number, 1 );
       
       if( $res->EOF )
           return false;
       
       $ToReturn = array();
       for( $x = 0; $x < ado_num_fields($res); $x++ )
       {
           if( $result_type == $ADO_NUM || $result_type == $ADO_BOTH )
               $ToReturn[ $x ] = $res->Fields[$x]->Value;
           if( $result_type == $ADO_ASSOC || $result_type == $ADO_BOTH )
               $ToReturn[ $res->Fields[$x]->Name ] = $res->Fields[$x]->Value;
       }
       $res->MoveNext();
       return $ToReturn;
   }
   
   function ado_num_rows( $res )
   {
       return $res->RecordCount;
   }
   
   function ado_free_result( $res )
   {
       $res->Close();
   }
   
   function ado_query( $link, $query )
   {
       return $link->Execute($query);
   }
   
   function ado_fetch_assoc( $res,  $row_number = -1 )
   {
       global $ADO_ASSOC;
       return  ado_fetch_array( $res, $ADO_ASSOC, $row_number);
   }
   
   function ado_fetch_row( $res,  $row_number = -1 )
   {
       global $ADO_NUM;
       return ado_fetch_array( $res, $ADO_NUM, $row_number);
   }
   
   // Extra functions:
   function ado_field_len( $res, $field_number )
   {
       return $res->Fields[$field_number]->Precision;
   }
   
   function ado_field_name( $res, $field_number )
   {
       return $res->Fields[$field_number]->Name;
   }
   
   function ado_field_scale( $res, $field_number )
   {
       return $res->Fields[$field_number]->NumericScale;
   }
   
   function ado_field_type( $res, $field_number )
   {
       return $res->Fields[$field_number]->Type;
   }
?>