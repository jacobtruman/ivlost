<?php
include('head.php');
include ($root.'/pdfclass/class.ezpdf.php');
$pdf =& new Cezpdf();
$pdf->selectFont($root.'./pdfclass/fonts/Helvetica.afm');
$i = 0;
while ($i < $count){
$i1 = $i+1;
$i2 = $i+2;
$data = array(
array('1'=>$fname[$i].' '.$lname[$i], '2'=>$fname[$i1].' '.$lname[$i1], '3'=>$fname[$i2].' '.$lname[$i2]),
array('1'=>$address[$i].' '.$unit[$i], '2'=>$address[$i1].' '.$unit[$i1], '3'=>$address[$i2].' '.$unit[$i2]),
array('1'=>$city[$i].' '.$state[$i].' '.$zip[$i], '2'=>$city[$i1].' '.$state[$i1].' '.$zip[$i1], '3'=>$city[$i2].' '.$state[$i2].' '.$zip[$i2])
);
//$pdf->ezText($address[$i].' '.$unit[$i], 10);
//$pdf->ezText($city[$i].' '.$state[$i].' '.$zip[$i], 10);
//$pdf->ezText('', 10);

$pdf->ezTable($data,array('1'=>'', '2'=>'', '3'=>''), '', array('showHeadings'=>0, 'shaded'=>0, 'width'=>500), array('1'=>array('width'=>100)), array('2'=>array('width'=>100)), array('3'=>array('width'=>100)));
$i = $i + 3;
}
$pdf->ezStream();
?>