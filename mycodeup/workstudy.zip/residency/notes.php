<?php
include('head.php');
$ptype = 'Residency Application Notes';
include($root.'/ado.php');
$dsn = 'c:/apache2triad/MINE/workstudy.mdb';
$link = ado_connect( $dsn );
$sql = "SELECT * from residency where (lnum = '".$_POST['lnum']."')";
//echo $sql;
$res = ado_query( $link, $sql );

$lnum = $res->Fields['lnum']->Value;
$notes = $res->Fields['notes']->Value;

ado_free_result( $res );
ado_close( $link );

/*function win_nl2br($stringtext) { 
return str_replace("\r\n", "<br>", $stringtext); 
} 

function win_br2nl($stringtext) { 
return str_replace("<br>", "\r\n", $stringtext); 
}*/
?>
<HEAD>
<Title>
    <?php echo $ptype?>
</Title>
<LINK Rel='stylesheet' Type='text/css' HREF='/style.css'>
</HEAD>
<body marginwidth='0' marginheight='0' scroll='yes' vlink='#0000FF' alink='#0000FF'>
	<table class='main' cellpadding='0' cellspacing='0' border='0' width='100%' height='100%'>
		<TR valign='top'>
			<TD WIDTH='100%' height='29' colspan='3'>
				<table class='bannerframe' border='0' cellspacing='0' cellpadding='3' width='100%'>
					<tr>
						<td nowrap valign='middle' align='left' height='30' width='100%'>
						</td>
					</tr>
				</table>				
				<table border='0' cellspacing='0' cellpadding='0' width='100%' height='15'>
					<tr>
					   <td bgcolor='#D8D8D8' align='center'>
						  	<font size='4' face='Times New Roman'>
								<b>
									<?php echo $ptype?>
								</b>
							</font>
						</td>
					</tr>
				</table>
			</TD>
		 </tr>
		 <tr valign='top' height=100%>
			<td width='100%' height='100%' valign='top' colspan='2'>
<center>
<BR>
<TABLE border='0' bordercolor='#COCOCO' cellpadding='0' cellspacing='4'>
	<TR>
		<TD colspan='2' align='center'>
			<B>
				Notes
			</B>
		</TD>
	</TR>
	<?php
		echo "<TR><TD colspan='2' align='center'>";
		echo "<b>Notes History</b>";
		echo "</TD></TR>";
		echo "<TR><TD colspan='2'>";
		echo nl2br($notes);
		echo "</TD></TR>";
	?>
</TABLE>
</form>
</center>
</BODY>
</table>