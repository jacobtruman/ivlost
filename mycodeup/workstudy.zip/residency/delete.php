<?php
include('head.php');
include($root.'/ado.php');
$dsn = "c:/apache2triad/MINE/workstudy.mdb";
$link = ado_connect( $dsn );

$sql = "DELETE from residency WHERE lnum = '".$lnum."'";
$res = ado_query( $link, $sql );

ado_close( $link );
?>
<script>
setTimeout("self.close()",500);
</script>