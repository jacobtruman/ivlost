<?php
include('head.php');
$ptype = 'Residency Entry';
include($root.'/ado.php');
?>
<HEAD>
<Title>
    <?php echo $ptype?>
</Title>
<LINK Rel='stylesheet' Type='text/css' HREF='/style.css'>
</HEAD>
<body marginwidth='0' marginheight='0' scroll='yes' vlink='#0000FF' alink='#0000FF'>
	<table class='main' cellpadding='0' cellspacing='0' border='0' width='100%' height='100%'>
		<TR valign='top'>
			<TD WIDTH='100%' height='29' colspan='3'>
				<table class='bannerframe' border='0' cellspacing='0' cellpadding='3' width='100%'>
					<tr>
						<td nowrap valign='middle' align='left' height='30' width='100%'>
						</td>
					</tr>
				</table>				
				<table border='0' cellspacing='0' cellpadding='0' width=100%>
					<tr>
					   <td bgcolor='#D8D8D8' align='center'>
							<?php echo $ptype?>
						</td>
					</tr>
				</table>
			</TD>
		 </tr>
		 <tr valign='top' height='100%'>
			<td width='100%' height='100%' valign='top' colspan='2'>
<center>
<BR>
<BR>
<BR>
<?php
$dsn = "c:/apache2triad/MINE/workstudy.mdb";
$lnum = $_POST['lnum'];
$link = ado_connect( $dsn );

$boxvals = array($b1, $b2, $b3, $b4, $b5, $b6);
for ($i = 0; $i < 6; $i++){
	if ($boxvals[$i] == 'on'){
		$boxes[$i] = 'checked';
	}else{
		$boxes[$i] = 'unchecked';
	}
}
$lname = strtoupper($_POST['lname']);
$fname = strtoupper($_POST['fname']);
$mid = strtoupper($_POST['mid']);
$address = strtoupper($_POST['address']);
$unit = strtoupper($_POST['unit']);
$city = strtoupper($_POST['city']);
$state = strtoupper($_POST['state']);
$resicode = strtoupper($_POST['resicode']);
if ($ddate == ''){
	$ddate = $pdate;
}else{
	$ddate = strtotime($ddate);
}

$notes = $pnotes."<font color='#0000FF'><-- Last Updated: ".date("D M j G:i:s")." - ".$status_list[$status]." --></font><BR>".$notes."<BR>";
$notes = stripslashes(eregi_replace("'",'"', $notes));
$sql = "UPDATE residency SET lname = '".$lname."', fname = '".$fname."', mid = '".$mid."', address = '".$address."', unit = '".$unit."', city = '".$city."', state = '".$state."', zip = '".$zip."', status = '".$status."', ddate = '".$ddate."', resiy = '".$resiy."', resis = '".$resis."', admity = '".$admity."', admits = '".$admits."', resicode = '".$resicode."', lnum = '".$lnum."', notes = '".$notes."', b1 = '".$boxes[0]."', b2 = '".$boxes[1]."', b3 = '".$boxes[2]."', b4 = '".$boxes[3]."', b5 = '".$boxes[4]."', b6 = '".$boxes[5]."', b7 = '".$b7."', b8 = '".$b8."', csrname = '".$csrname."' WHERE lnum = '".$lnum."'";
$res = ado_query( $link, $sql );

ado_close( $link );
$msg = "<b>".$lnum."</b> Updated Successfully!";
$thebutton = "Click Here to Return to the Record";
$thesbutton = "Click Here to Submit Another New One?";

echo $msg;
?>
<form name='formname' method='POST' action='update.php'>
<input type='hidden' name='lnum' value='<?php echo $lnum;?>'>
<TABLE>
	<TR>
		<TD ALIGN='center' colspan='2'>
			<input type='submit' value='<?php echo $thebutton;?>' CLASS='textbutton'>
		</TD>
	</TR>
</TABLE>
</form>

<form>
<TABLE>
	<TR>
		<TD ALIGN='center' colspan='2'>
			<input type='submit' value='Click here to close' CLASS='textbutton' onclick='javascrip:window.close();'>
		</TD>
	</TR>
</TABLE>
</form>

<form name='formname' method='POST' action='submit.php'>
<TABLE>
	<TR>
		<TD ALIGN='center' colspan='2'>
			<input type='submit' value='<?php echo $thesbutton;?>' CLASS='textbutton'>
		</TD>
	</TR>
</TABLE>
</form>
<BR>
<BR>
<BR>
<HR>
</center>
</BODY>
</table>
<script>
setTimeout("self.close()",50000);
</script>