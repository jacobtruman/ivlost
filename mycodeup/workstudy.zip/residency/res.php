<?php
include('head.php');
$ptype = "Residency Entry";
include($root.'/ado.php');
?>
<HEAD>
<Title>
    <?php echo $ptype?>
</Title>
<LINK Rel='stylesheet' Type='text/css' HREF='/style.css'>
</HEAD>
<body marginwidth='0' marginheight='0' scroll='yes' vlink='#0000FF' alink='#0000FF'>
	<table class='main' cellpadding='0' cellspacing='0' border='0' width='100%' height='100%'>
		<TR valign='top'>
			<TD WIDTH='100%' height='29' colspan='3'>
				<table class='bannerframe' border='0' cellspacing='0' cellpadding='3' width='100%'>
					<tr>
						<td nowrap valign='middle' align='left' height='30' width='100%'>
						</td>
					</tr>
				</table>				
				<table border='0' cellspacing='0' cellpadding='0' width=100%>
					<tr>
					   <td bgcolor='#D8D8D8' align='center'>
							<?php echo $ptype?> Result
						</td>
					</tr>
				</table>
			</TD>
		 </tr>
		 <tr valign='top' height=100%>
			<td width='100%' height='100%' valign='top' colspan='2'>
<center>
<BR>
<BR>
<BR>
<?php
$dsn = "c:/apache2triad/MINE/workstudy.mdb";
$link = ado_connect( $dsn );

if (isset($_POST['lnum'])){
	$lnum = $_POST['lnum'];
	$resi = $_POST['resiy']."-".$_POST['resis'];
	$sql1 = "SELECT lnum from residency where (lnum = 'L000".$lnum."') AND (resiy = '".$resiy."') AND (resis = '".$resis."')";
	//echo $sql1;
	$res1 = ado_query( $link, $sql1 );
	$i = 0;
	while (!$res1->EOF){
		$lnum2 = $res1->Fields['lnum']->Value;
		$i++;
		$res1->MoveNext();
	}
	if ($i == 0){

		$sql = "INSERT INTO residency (rdate, lnum, lname, fname, mid, address, unit, city, state, zip, admity, admits, resiy, resis, resicode, status, csrname) VALUES ('".$rdate."', 'L000".$lnum."', '".$lname."', '".$fname."', '".$mid."', '".$address."', '".$unit."', '".$city."', '".$state."', '".$zip."', '".$admity."', '".$admits."', '".$resiy."', '".$resis."', '".$resicode."', '".$status."', '".$csrname."')";
		$sql = strtoupper($sql);
		$res = ado_query( $link, $sql );

		$msg = "<b>L000".$_POST['lnum']."</b> Entered Successfully!";
		$thebutton = "Click Here to Submit Another?";
	}else{
		$msg = "<font color='#FF0000'><B>Failed!</B></font><BR><BR>An application for <B>".$lnum2."</B> has already been entered for the <B>".$resi."</B> term.";
		$thebutton = "Click Here to Try again?";
	}

	ado_free_result( $res1 );
	
}else{
	$msg = "<font color='#FF0000'><B>Error!!</B></font> You need to start from the index page.<BR> <a href='index.php'>Click here</a>.";
}
echo $msg;

ado_close( $link );
?>
<form name='formname' method='POST' action='submit.php'>
<TABLE>
	<TR>
		<TD ALIGN='center' colspan='2'>
			<input type='submit' value='<?php echo $thebutton;?>' CLASS='textbutton'>
		</TD>
	</TR>
</TABLE>
</form>

<form>
<TABLE>
	<TR>
		<TD ALIGN='center' colspan='2'>
			<input type='submit' value='Click here to close' CLASS='textbutton' onclick='javascrip:window.close();'>
		</TD>
	</TR>
</TABLE>
</form>

<form name='formname' method='POST' action='update.php'>
<input type='hidden' name='lnum' value='L000<?php echo $lnum;?>'>
<TABLE>
	<TR>
		<TD ALIGN='center' colspan='2'>
			<input type='submit' value='View this Record' CLASS='textbutton'>
		</TD>
	</TR>
</TABLE>
</form>
<BR>
<BR>
<BR>
<HR>
</center>
</BODY>
</table>
<script>
setTimeout("self.close()",50000);
</script>