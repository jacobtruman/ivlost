<?php
$root = 'c:/apache2triad/htdocs';

$obj['0'] = '&nbsp;';
$obj['1'] = 'APPROVED - CLIENT SERVICES';
$obj['2'] = 'APPROVED - APPEALS COMMITTEE';
$obj['3'] = 'DENIED - CLIENT SERVICES';
$obj['4'] = 'DENIED - APPEALS COMMITTEE';
$obj['5'] = 'INCOMPLETE';
$obj['6'] = 'DENIED - CLOSED';
$status_list = $obj;

$obj['0'] = '#FFFFFF';
$obj['1'] = '#B7E6DB';
$obj['2'] = '#9F95FF';
$obj['3'] = '#EEAEAE';
$obj['4'] = '#FF8282';
$obj['5'] = '#FFFC8C';
$obj['6'] = '#FFFFFF';
$status_color = $obj;

$obj['1'] = 'SPRING';
$obj['2'] = 'SUMMER';
$obj['3'] = 'FALL';
$term = $obj;

$csrs = array('Karen Calder', 'Rolando Flores', 'Joanna Jezierska', 'Raelynn Lee', 'Ana Martinez', 'Emily Rafael', 'Ed Ronca');

?>