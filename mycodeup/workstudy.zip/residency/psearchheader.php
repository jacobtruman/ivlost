<HEAD>
<Title>
	<?php echo $ptype;?>
</Title>
<LINK Rel='stylesheet' Type='text/css' HREF='/style.css'>
</HEAD>
<body marginwidth='0' marginheight='0' scroll='yes' vlink='#0000FF' alink='#0000FF'>
	<table class='main' cellpadding='0' cellspacing='0' border='0' width='100%' height='100%'>
		<TR valign='top'>
			<TD WIDTH='100%' height='29' colspan='3'>
				<table class='bannerframe' border='0' cellspacing='0' cellpadding='3' width='100%'>
					<tr>
						<td nowrap valign='middle' align='left' height='30'>
						</td>
					</tr>
				</table>
				<table border='0' cellspacing='0' cellpadding='0' width='100%' height='15'>
					<tr>
					   <td bgcolor='#D8D8D8' align='center'>
						  	<font size='4' face='Times New Roman'>
								<b>
									<?php echo $ptype?>
								</b>
							</font>
						</td>
					</tr>
				</table>
			</TD>
		</TR>
		<tr valign='top'>
			<td width='118' height='435' valign='top' rowspan='2'>
			<BR>
				<table valign='top' cellpadding='0' border='0' cellspacing='0'>
					<TR>
						<TD>
							<BR><BR>
						</TD>
					</TR>
					<TR>
						<TD>
							<form name='submitform' method='POST' action='submit.php' target='_blank'>
								<input type='submit' value='Submit New Application' CLASS='textbutton'>
							</form>
						</TD>
					</TR>
					<tr>
						<td>
						<?php
						if (isset($_POST['lname'])){
							$lname = $_POST['lname'];
						}else{
							$lname = '';
						}
						if (isset($_POST['status'])){
							$status = $_POST['status'];
						}else{
							$rdate = '';
						}
						if (isset($_POST['fname'])){
							$fname = $_POST['fname'];
						}else{
							$fname = '';
						}
						?>
							<form METHOD='POST' ACTION='<?php echo $_SERVER['PHP_SELF'];?>'>
								<font size='2' face='Verdana'>
									Last Name
									<BR>
									<input TYPE='TEXT' NAME='lname' VALUE='<?php echo $lname;?>' size='20' class='formfield'>
									<BR>
									First Name
									<BR>
									<input TYPE='TEXT' NAME='fname' VALUE='<?php echo $fname;?>' size='20' class='formfield'>
									<BR>
									Status
									<BR>
									<select NAME='status' CLASS='formfield'>
										<?php
											if ($status != ''){
												$sbgcolor = $status_color[$status];
												if ($sbgcolor == '#000000'){
													$sbgcolor = '#FFFFFF';
												}
												echo "<option value='".$status."' style='BACKGROUND-COLOR:".$sbgcolor."' selected>".$status_list[$status]."</option>";
												echo "<option></option>";
											}else{
												echo "<option></option>";
											}
											
										for ($i = 1; $i <= 5; $i++){
											$sbgcolor = $status_color[$i];
											if ($sbgcolor == '#000000'){
												$sbgcolor = '#FFFFFF';
											}
											echo "<option value='".$i."' style='BACKGROUND-COLOR:".$sbgcolor."'>".$status_list[$i]."</option>\n";
										}
										?>
									</select>
									<BR>
									<BR>
									<input type='submit' name='submit' value='Search' class='formbutton'>
								</font>
							</form>
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr valign=top height=100%>
			<td width='100%' valign='top' colspan='2'>