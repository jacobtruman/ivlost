<?php
include('head.php');
$ptype = 'Residency Application Entry';
?>
<HEAD>
<Title>
    <?php echo $ptype?>
</Title>
<script>
function form_focus()
{
	formname.resiy.focus();
}

function isEmpty(string) {
	if (!string){
		alert(emptyfldmsg);
		return false;
	}
}

function isProper(string) {
var iChars = "!@#$%^&*()_+-=<>?,./:`~\\|/?\";'{}[]";
	for (var i = 0; i < string.length; i++) {
		if (iChars.indexOf(string.charAt(i)) != -1){
			alert(spcharsmsg);
			return false;
		}
	}
	return true;
}

function isProperDigits(string) {
var iChars = "!@#$%^&*()_+-=<>?,./:`~\\|/?\";'{}[]abcdefghijklmnopqrstuvwxyz";
	for (var i = 0; i < string.length; i++) {
		if (iChars.indexOf(string.charAt(i)) != -1){
			alert(numsmsg);
			return false;
		}
	}
	return true;
}

emptyfldmsg = 'Please complete all the required fields.';
spcharsmsg = 'No special characters please.';
numsmsg = 'Numbers only please.';

function vcheck(theform){

if (theform.resiy[formname.resiy.selectedIndex].value == ''){
	alert(emptyfldmsg);
	formname.resiy.focus();
	return (false);
}

if (formname.resis[theform.resis.selectedIndex].value == ''){
	alert(emptyfldmsg);
	theform.resis.focus();
	return (false);
}

if (isProperDigits(theform.lnum.value) == false) {
	theform.lnum.focus();
	return false;
}

if (theform.lnum.value.length < 6){
	alert(emptyfldmsg);
	theform.lnum.focus();
	return (false);
}

if (isEmpty(theform.lname.value) == false){
	theform.lname.focus();
	return false;
}else if (isProper(theform.lname.value) == false){
	theform.lname.focus();
	return false;
}

if (isEmpty(theform.fname.value) == false){
	theform.fname.focus();
	return false;
}else if (isProper(theform.fname.value) == false){
	theform.fname.focus();
	return false;
}

if (isProper(theform.mid.value) == false){
	theform.mid.focus();
	return false;
}

if (isEmpty(theform.address.value) == false){
	theform.address.focus();
	return false;
}else if (isProper(theform.address.value) == false){
	theform.address.focus();
	return false;
}

if (isProper(theform.unit.value) == false){
	theform.unit.focus();
	return false;
}

if (isEmpty(theform.city.value) == false){
	theform.city.focus();
	return false;
}else if (isProper(theform.city.value) == false){
	theform.city.focus();
	return false;
}

if (isEmpty(theform.state.value) == false){
	theform.state.focus();
	return false;
}else if (isProper(theform.state.value) == false){
	theform.state.focus();
	return false;
}

if (isProper(theform.zip.value) == false){
	theform.zip.focus();
	return false;
}

if (theform.zip.value.length < 5){
	alert(emptyfldmsg);
	theform.zip.focus();
	return (false);
}
  
if (theform.admity[theform.admity.selectedIndex].value == ''){
	alert(emptyfldmsg);
	theform.admity.focus();
	return (false);
}

if (theform.admits[theform.admits.selectedIndex].value == ''){
	alert(emptyfldmsg);
	theform.admits.focus();
	return (false);
}

if (theform.resicode[theform.resicode.selectedIndex].value == ''){
	alert(emptyfldmsg);
	theform.resicode.focus();
	return (false);
}

}
</script>
<LINK Rel='stylesheet' Type='text/css' HREF='/style.css'>
</HEAD>
<body marginwidth='0' marginheight='0' scroll='yes' vlink='#0000FF' alink='#0000FF' onload='form_focus();'>
	<table class='main' cellpadding='0' cellspacing='0' border='0' width='100%' height='100%'>
		<TR valign='top'>
			<TD WIDTH='100%' height='29' colspan='3'>
				<table class='bannerframe' border='0' cellspacing='0' cellpadding='3' width='100%'>
					<tr>
						<td nowrap valign='middle' align='left' height='30' width='100%'>
						</td>
					</tr>
				</table>				
				<table border='0' cellspacing='0' cellpadding='0' width='100%' height='15'>
					<tr>
					   <td bgcolor='#D8D8D8' align='center'>
						  	<font size='4' face='Times New Roman'>
								<b>
									<?php echo $ptype?>
								</b>
							</font>
						</td>
					</tr>
				</table>
			</TD>
		 </tr>
		 <tr valign='top' height=100%>
			<td width='100%' height='100%' valign='top' colspan='2'>
<center>
<BR>
<?php
if ($_POST['next'] == '1'){
	echo '<b>'.ucfirst($fname).' '.ucfirst($mid).' '.ucfirst($lname).'</b> Entered Successfully';
}
?>
<BR>
<BR>
<font style='FONT-SIZE:10pt;'>
	<B>
		No special characters please. 
	</B>
</font>
<BR>
<BR>
Required fields are
	<font color='#FF0000'>
		<B>
			red
		</B>
	</font>
<form name='formname' method='POST' action='res.php' onsubmit='return vcheck(this);'>
<INPUT TYPE='hidden' name='next' value='1'>
<INPUT TYPE='hidden' name='status' value='0'>
<TABLE border='0' bordercolor='#COCOCO' cellpadding='0' cellspacing='3'>
	<TR>
		<TD colspan='2' align='center'>
			<B>
				Residency Application Term
			</B>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			<font color='#FF0000'>
				<B>
					Year
				</B>
			</font>
			<select NAME='resiy' CLASS='formfield'>
				<option selected>Select One</option>
				<?php
					$n = date("Y");
					for ($i = 0; $i < 10; $i++){
						echo "<option value='".$n."'>".$n."</option>\n";
						$n++;
					}
				?>
			</select>
		</TD>
		<TD>
			<font color='#FF0000'>
				<B>
					Semester
				</B>
			</font>
			<select NAME='resis' CLASS='formfield'>
				<option selected>Select One</option>
				<option value='1'>Spring</option>
				<option value='3'>Fall</option>
			</select>
		</TD>
	</TR>
	<TR>
		<TD>
			<BR>
		</TD>
		<TD>
			<BR>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			<B>
				Date
			</B>
		</TD>
		<TD>
			<B><?php echo date("n/j/Y");?></B>
			<INPUT TYPE='hidden' NAME='rdate' VALUE='<?php echo date("n/j/Y");?>'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			<font color='#FF0000'>
				<B>
					L Number
				</B>
			</font>
		</TD>
		<TD>
			L000 <INPUT NAME='lnum' SIZE='8' CLASS='formfield' maxlength='6' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			<font color='#FF0000'>
				<B>
					Last Name
				</B>
			</font>
		</TD>
		<TD>
			<INPUT NAME='lname' SIZE='25' CLASS='formfield' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			<font color='#FF0000'>
				<B>
					First Name
				</B>
			</font>
		</TD>
		<TD>
			<INPUT NAME='fname' SIZE='25' CLASS='formfield' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			<B>
				Middle Initial
			</B>
		</TD>
		<TD>
			<INPUT NAME='mid' SIZE='1' CLASS='formfield' maxlength='1' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			<font color='#FF0000'>
				<B>
					Street Address
				</B>
			</font>
		</TD>
		<TD>
			<INPUT NAME='address' SIZE='35' CLASS='formfield' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			<B>
				Apt/Ste/Unit Number
			</B>
		</TD>
		<TD>
			<INPUT NAME='unit' SIZE='10' CLASS='formfield' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			<font color='#FF0000'>
				<B>
					City
				</B>
			</font>
		</TD>
		<TD>
			<INPUT NAME='city' SIZE='35' CLASS='formfield' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			<font color='#FF0000'>
				<B>
					State
				</B>
			</font>
		</TD>
		<TD>
			<INPUT NAME='state' SIZE='3' CLASS='formfield' maxlength='2' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			<font color='#FF0000'>
				<B>
					Zip
				</B>
			</font>
		</TD>
		<TD>
			<INPUT NAME='zip' SIZE='7' CLASS='formfield' maxlength='5' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD colspan='2' align='center'>
			<B>
				Admit Term
			</B>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			<font color='#FF0000'>
				<B>
					Year
				</B>
			</font>
			<select NAME='admity' CLASS='formfield'>
				<option selected>Select One</option>
				<?php
					$n = date("Y") - 15;
					for ($i = 0; $i < 17; $i++){
						echo "<option value='".$n."'>".$n."</option>\n";
						$n++;
					}
				?>
			</select>
		</TD>
		<TD>
			<font color='#FF0000'>
				<B>
					Semester
				</B>
			</font>
			<select NAME='admits' CLASS='formfield'>
				<option selected>Select One</option>
				<option value='1'>Spring</option>
				<option value='2'>Summer</option>
				<option value='3'>Fall</option>
			</select>
		</TD>
	</TR>
	<TR>
		<TD>
			<BR>
		</TD>
		<TD>
			<BR>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			<font color='#FF0000'>
				<B>
					Residency Code
				</B>
			</font>
		</TD>
		<TD>
			<select NAME='resicode' CLASS='formfield'>
				<option selected>Select One</option>
				<option value='A'>A</option>
				<option value='B'>B</option>
				<option value='C'>C</option>
				<option value='D'>D</option>
				<option value='E'>E</option>
				<option value='F'>F</option>
				<option value='I'>I</option>
			</select>
		</TD>
	</TR>
	<TR>
		<TD>
			<BR>
		</TD>
		<TD>
			<BR>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='center' colspan='2'>
			<input type='submit' value='Submit' CLASS='formbutton'>
		</TD>
	</TR>
</TABLE>
</form>
</center>
</BODY>