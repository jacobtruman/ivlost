<?php
	header ("Location: http://wsentry/");
?>