<?php
include('head.php');
$ptype = 'Residency Search Page';
include('psearchheader.php');
include($root.'/ado.php');


$dsn = "c:/apache2triad/MINE/workstudy.mdb";
$link = ado_connect( $dsn );

$j = $k = 0;
while (list($key, $value) = each ($_POST)){
$nkey = str_replace('pass', '',$key);
	if ($nkey == 'submit'){
	}else{
		if ($value == ''){
			$sval[$j] = '';//$nkey." LIKE '%' AND ";
		}else{
			if ($k == '0'){
				$sval[$j] = "WHERE ".$nkey." LIKE '%".$value."%' AND ";
				$k++;
			}else{
				$sval[$j] = $nkey." LIKE '%".$value."%' AND ";
			}
		}
	$j++;
	}
}
$svalues = '';
if ($sval != ''){
	while (list($nkey, $value) = each ($sval)){
	$svalues .= ($value);
	}
}
$svals = substr($svalues, 0, -4);


$order = 'lname, fname, rdate';

if ($lname == '*'){
	$sql = "SELECT * FROM residency ORDER BY ".$order;
}else if ($k == '0'){
	$sql = "SELECT * FROM residency WHERE status = 'NULL' ORDER BY ".$order;
}else{
	$sql = "SELECT * FROM residency ".$svals." ORDER BY ".$order;
}
//echo $sql;
$res = ado_query( $link, $sql );

$i = 0;
while (!$res->EOF){
	$i++;
	$res->MoveNext();
}
$res = ado_query( $link, $sql );
?>
</form>
<BR>
<?php echo "<center><b>".$i."</b> Record(s) Found</center>";?>
<BR>
<table width='90%' border='1' cellpadding='0' cellspacing='0' bordercolor='#C0C0C0' align='center'>
	<thead>
		<tr>
			<td><b>L Number</b></td>
			<td><b>Name</b></td>
			<td><b>Notes</b></td>
			<td><b>Admit Term</b></td>
			<td><b>Resi. App. Term</b></td>
			<td><b>Resi. Code</b></td>
			<td><b>Status</b></td>
			<td><b>Denied Date</b></td>
		</tr>
	</thead>
<tbody>
<?php
while (!$res->EOF){
	$lnum = $res->Fields['lnum']->Value;
	$lname = $res->Fields['lname']->Value;
	$fname = $res->Fields['fname']->Value;
	$mid = $res->Fields['mid']->Value;
	$rdate = $res->Fields['rdate']->Value;
	$address = $res->Fields['address']->Value;
	$city = $res->Fields['city']->Value;
	$state = $res->Fields['state']->Value;
	$zip = $res->Fields['zip']->Value;
	$status = $res->Fields['status']->Value;
	$resiy = $res->Fields['resiy']->Value;
	$resis = $res->Fields['resis']->Value;
	$admity = $res->Fields['admity']->Value;
	$admits = $res->Fields['admits']->Value;
	$resicode = $res->Fields['resicode']->Value;
	$pnotes = $res->Fields['notes']->Value;
	$ddate = $res->Fields['ddate']->Value;
	$gdate = getdate($ddate);

	if ($ddate == ''){
		$thedate = '&nbsp;';
	}else{
		$thedate = $gdate['mon']."/".$gdate['mday']."/".$gdate['year'];
	}
	
	if ($ddate != ''){
		$edate = $ddate+86400*35;
		$cdate = time();
		$response = 'The student did not respond within 30 days - Closing file';
		if ($cdate > $edate){
			//if (strpos($notes, $response)){
			if (($status != '3') && ($status != '4')){
			}else{
				$status = '6';
				$link2 = ado_connect( $dsn );

				$notes = $pnotes."<font color='#0000FF'><-- Last Updated: ".date("D M j G:i:s")." - ".$status." --></font><BR>".$response."<BR>";
				$notes = stripslashes(eregi_replace("'",'"', $notes));
				$sql2 = "UPDATE residency SET notes = '".$notes."', status = '".$status."' WHERE lnum = '".$lnum."'";
				$res2 = ado_query( $link2, $sql2 );

				ado_close( $link2 );
			}
		}else{
		}
	}
	
	$bgcolor = $status_color[$status];
	if ($bgcolor == '#000000'){
		$bgcolor = '#FFFFFF';
	}

	echo "<tr><td bgcolor='".$bgcolor."'>\n";
	echo "<form name='formname' method='POST' action='update.php' target='update'>\n";
	echo "<input type='submit' value='".$lnum."' class='textbutton' style='BACKGROUND-COLOR:".$bgcolor.";'>\n";
	echo "<input type='hidden' name='lnum' value='".$lnum."'>\n";
	echo "</form>\n";
	echo "</td><td bgcolor='".$bgcolor."'>\n";
	echo $lname.", ".$fname." ".$mid."\n";
	echo "</td><td bgcolor='".$bgcolor."'>\n";
	//echo $address."<BR>\n";
	//echo $city.", ".$state." ".$zip."\n";
	echo "<form name='formname' method='POST' action='notes.php' target='_blank'>\n";
	if ($pnotes == ''){
		echo "<input type='submit' value='Notes' class='textbutton' style='BACKGROUND-COLOR:".$bgcolor.";' disabled>\n";
	}else{
		echo "<input type='submit' value='Notes' class='textbutton' style='BACKGROUND-COLOR:".$bgcolor.";'>\n";
	}
	echo "<input type='hidden' name='lnum' value='".$lnum."'>\n";
	echo "</form>\n";
	echo "</td><td bgcolor='".$bgcolor."'>\n";
	echo $admity."-".$admits."\n";
	echo "</td><td bgcolor='".$bgcolor."'>\n";
	echo $resiy."-".$resis."\n";
	echo "</td><td bgcolor='".$bgcolor."'>\n";
	echo $resicode."\n";
	echo "</td><td bgcolor='".$bgcolor."'>\n";
	echo $status_list[$status]."\n";
	echo "</td><td bgcolor='".$bgcolor."'>\n";
	echo $thedate."</TD></TR>\n";
$res->MoveNext();
}
ado_free_result( $res );
ado_close( $link );

echo "</tbody></table></table></table></body>";
?>
<!-- Created by Jacob Truman -->