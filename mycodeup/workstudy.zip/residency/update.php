<?php
include('head.php');
$ptype = 'Residency Application Update';
include($root.'/ado.php');
$dsn = 'c:/apache2triad/MINE/workstudy.mdb';
$link = ado_connect( $dsn );
$sql = "SELECT * from residency where (lnum = '".$_POST['lnum']."')";
//echo $sql;
$res = ado_query( $link, $sql );

$lnum = $res->Fields['lnum']->Value;
$lname = $res->Fields['lname']->Value;
$fname = $res->Fields['fname']->Value;
$mid = $res->Fields['mid']->Value;
$rdate = $res->Fields['rdate']->Value;
$address = $res->Fields['address']->Value;
$unit = $res->Fields['unit']->Value;
$city = $res->Fields['city']->Value;
$state = $res->Fields['state']->Value;
$zip = $res->Fields['zip']->Value;
$status = $res->Fields['status']->Value;
$resiy = $res->Fields['resiy']->Value;
$resis = $res->Fields['resis']->Value;
$admity = $res->Fields['admity']->Value;
$admits = $res->Fields['admits']->Value;
$resicode = $res->Fields['resicode']->Value;
$notes = $res->Fields['notes']->Value;
$ddate = $res->Fields['ddate']->Value;
$b1 = $res->Fields['b1']->Value;
$b2 = $res->Fields['b2']->Value;
$b3 = $res->Fields['b3']->Value;
$b4 = $res->Fields['b4']->Value;
$b5 = $res->Fields['b5']->Value;
$b6 = $res->Fields['b6']->Value;
$b7 = $res->Fields['b7']->Value;
$b8 = $res->Fields['b8']->Value;
$csrname = $res->Fields['csrname']->Value;

if ($ddate != ''){
	$gdate = getdate($ddate);
	$fdate = $gdate['mon']."/".$gdate['mday']."/".$gdate['year'];
}else{
	$fdate = '';
}

ado_free_result( $res );
ado_close( $link );

function win_nl2br($stringtext) { 
return str_replace("\r\n", "<br>", $stringtext); 
} 

function win_br2nl($stringtext) { 
return str_replace("<br>", "\r\n", $stringtext); 
}
?>
<HEAD>
<Title>
    <?php echo $ptype?>
</Title>
<LINK Rel='stylesheet' Type='text/css' HREF='/style.css'>
</HEAD>
<body marginwidth='0' marginheight='0' scroll='yes' vlink='#0000FF' alink='#0000FF' onload='page_load();'>
	<table class='main' cellpadding='0' cellspacing='0' border='0' width='100%' height='100%'>
		<TR valign='top'>
			<TD WIDTH='100%' height='29' colspan='3'>
				<table class='bannerframe' border='0' cellspacing='0' cellpadding='3' width='100%'>
					<tr>
						<td nowrap valign='middle' align='left' height='30' width='100%'>
						</td>
					</tr>
				</table>				
				<table border='0' cellspacing='0' cellpadding='0' width='100%' height='15'>
					<tr>
					   <td bgcolor='#D8D8D8' align='center'>
						  	<font size='4' face='Times New Roman'>
								<b>
									<?php echo $ptype?>
								</b>
							</font>
						</td>
					</tr>
				</table>
			</TD>
		 </tr>
		 <tr valign='top' height=100%>
			<td width='100%' height='100%' valign='top' colspan='2'>
<center>
<BR>
<script>
function page_load(){
	Hide(allrows);
	bfocus();
}

function isEmpty(string) {
	if (!string){
		alert(emptyfldmsg);
		return false;
	}
}

function isProper(string) {
var iChars = "!@#$%^&*()_+-=<>?,./:`~\\|/?\";'{}[]";
	for (var i = 0; i < string.length; i++) {
		if (iChars.indexOf(string.charAt(i)) != -1){
			alert(spcharsmsg);
			return false;
		}
	}
	return true;
}

function isProperDigits(string) {
var iChars = "!@#$%^&*()_+-=<>?,./:`~\\|/?\";'{}[]abcdefghijklmnopqrstuvwxyz";
	for (var i = 0; i < string.length; i++) {
		if (iChars.indexOf(string.charAt(i)) != -1){
			alert(numsmsg);
			return false;
		}
	}
	return true;
}

emptyfldmsg = 'Please complete all the required fields.';
spcharsmsg = 'No special characters please.';
numsmsg = 'Numbers only please.';

function vcheck(theform){

if (theform.resiy[theform.resiy.selectedIndex].value == ''){
	alert(emptyfldmsg);
	theform.resiy.focus();
	return (false);
}

if (theform.resis[theform.resis.selectedIndex].value == ''){
	alert(emptyfldmsg);
	theform.resis.focus();
	return (false);
}

if (isProperDigits(theform.lnum.value) == false) {
	theform.lnum.focus();
	return false;
}

if (theform.lnum.value.length < 10){
	alert(emptyfldmsg);
	theform.lnum.focus();
	return (false);
}

if (isEmpty(theform.lname.value) == false){
	theform.lname.focus();
	return false;
}else if (isProper(theform.lname.value) == false){
	theform.lname.focus();
	return false;
}

if (isEmpty(theform.fname.value) == false){
	theform.fname.focus();
	return false;
}else if (isProper(theform.fname.value) == false){
	theform.fname.focus();
	return false;
}

if (isProper(theform.mid.value) == false){
	theform.mid.focus();
	return false;
}

if (isEmpty(theform.address.value) == false){
	theform.address.focus();
	return false;
}else if (isProper(theform.address.value) == false){
	theform.address.focus();
	return false;
}

if (isProper(theform.unit.value) == false){
	theform.unit.focus();
	return false;
}

if (isEmpty(theform.city.value) == false){
	theform.city.focus();
	return false;
}else if (isProper(theform.city.value) == false){
	theform.city.focus();
	return false;
}

if (isEmpty(theform.state.value) == false){
	theform.state.focus();
	return false;
}else if (isProper(theform.state.value) == false){
	theform.state.focus();
	return false;
}

if (isProper(theform.zip.value) == false){
	theform.zip.focus();
	return false;
}

if (theform.admity[theform.admity.selectedIndex].value == ''){
	alert(emptyfldmsg);
	theform.admity.focus();
	return (false);
}

if (theform.admits[theform.admits.selectedIndex].value == ''){
	alert(emptyfldmsg);
	theform.admits.focus();
	return (false);
}

if (theform.status[theform.status.selectedIndex].value != '5'){
	if (theform.csrname[theform.csrname.selectedIndex].value == ''){
		alert(emptyfldmsg);
		theform.csrname.focus();
		return (false);
	}
}

if (theform.zip.value.length < 5){
	alert(emptyfldmsg);
	theform.zip.focus();
	return (false);
}

if (theform.resicode[theform.resicode.selectedIndex].value == ''){
	alert(emptyfldmsg);
	theform.resicode.focus();
	return (false);
}

if ((theform.ddate.value == '') && ((theform.status[theform.status.selectedIndex].value == '3') || (theform.status[theform.status.selectedIndex].value == '4'))){
   	alert(emptyfldmsg);
    theform.ddate.focus();
   	return (false);
}

stval = theform.status[theform.status.selectedIndex].value
if (stval != ''){

}else{
    alert(emptyfldmsg);
   	theform.status.focus();
    return (false);
}

if (isEmpty(theform.notes.value) == false){
	theform.notes.focus();
	return false;
}

if(theform.status[theform.status.selectedIndex].value == '5'){
	if ((theform.b1.checked == false) && (theform.b2.checked == false) && (theform.b3.checked == false) && (theform.b4.checked == false) && (theform.b5.checked == false) && (theform.b6.checked == false)){
		alert('Please check at least one of the options below');
		theform.b6.focus();
		return false;
	}
	if (isEmpty(theform.b8.value) == false){
		theform.b8.focus();
		return false;
	}
}
}

function bfocus(){
if (<?php echo $status;?> == ''){
formname.status.focus();
}else{
formname.notes.focus();
}
check_status();
}

function check_status(){
	if((formname.status[formname.status.selectedIndex].value == '3') || (formname.status[formname.status.selectedIndex].value == '4')){
		formname.ddate.disabled = false;
		formname.img_ddate.disabled = false;
	}else{
		formname.ddate.disabled = true;
		formname.img_ddate.disabled = true;
	}
	if(formname.status[formname.status.selectedIndex].value == '5'){
		Hide(csr);
		Show(denyrow);
	}else{
		Show(csr);
		Hide(denyrow);
	}
	if(formname.status[formname.status.selectedIndex].value == '1'){
	msg = "Everything submitted\n";
		if (document.formname.notes.value == ''){
			document.formname.notes.value = document.formname.notes.value + msg;
		}else{
			document.formname.notes.value = document.formname.notes.value + "\n" + msg;
		}
	}
}
function check_ddate(){
	if((formname.status[formname.status.selectedIndex].value != '3') && (formname.status[formname.status.selectedIndex].value != '4')){
		formname.ddate.disabled = true;
	}
}

	function Hide(el_id){
			el_id.style.display="none";
	}

	function Show(el_id){
			el_id.style.display="";
	}
	
	function hideShow(el_id){
		var el=document.getElementById(el_id);
		if(el_id.style.display!="none"){
			el_id.style.display="none";
		}else{
			el_id.style.display="";
		}
	}
	
	function denyals(box){
		check_status();
		switch(box){
		case 1:
			msg = "Lacks proof of filing income tax from Nevada (signed 1040 and W2s) or pay stubs for the past 12 months.\n";
			if (document.formname.b1.checked == true){
				if (document.formname.notes.value == ''){
					document.formname.notes.value = document.formname.notes.value + msg;
				}else{
					document.formname.notes.value = document.formname.notes.value + "\n" + msg;
				}
			}
		break
		case 2:
			msg = "Lacks Documentation to support 12 continuous months of residency prior to the first day of the semester of instruction. (Rent receipts, power bills, water bills, mortgage statements, or bank statements).\n";
			if (document.formname.b2.checked == true){
				if (document.formname.notes.value == ''){
					document.formname.notes.value = document.formname.notes.value + msg;
				}else{
					document.formname.notes.value = document.formname.notes.value + "\n" + msg;
				}
			}
		break
		case 3:
			msg = "Lacks Nevada Driver license, Nevada vehicle registration, Nevada voter registration, or Nevada ID issued 12 months prior to the first day of the semester of instruction.\n";
			if (document.formname.b3.checked == true){
				if (document.formname.notes.value == ''){
					document.formname.notes.value = document.formname.notes.value + msg;
			}else{
					document.formname.notes.value = document.formname.notes.value + "\n" + msg;
				}
			}
		break
		case 4:
			msg = "Lacks clear and convincing, objective evidence of becoming a Nevada resident.\n";
			if (document.formname.b4.checked == true){
				if (document.formname.notes.value == ''){
					document.formname.notes.value = document.formname.notes.value + msg;
				}else{
					document.formname.notes.value = document.formname.notes.value + "\n" + msg;
				}
			}
		break
		case 5:
			msg = "Lacks documentation proving financial independence.\n";
			if (document.formname.b5.checked == true){
				if (document.formname.notes.value == ''){
					document.formname.notes.value = document.formname.notes.value + msg;
				}else{
					document.formname.notes.value = document.formname.notes.value + "\n" + msg;
				}
			}
		break
		case 6:
			msg = document.formname.b7.value + "\n";
			if (document.formname.b6.checked == true){
				if (document.formname.notes.value == ''){
					document.formname.notes.value = document.formname.notes.value + msg;
				}else{
					document.formname.notes.value = document.formname.notes.value + "\n" + msg;
				}
			}
		break
		}
	}

function check_boxes(){
	if(formname.b6.checked == true){
		formname.b7.disabled = false;
	}else{
		formname.b7.disabled = true;
	}
}
</script>
Required fields are
	<font color='#FF0000'>
		<B>
			red
		</B>
	</font>
<form name='formname' method='POST' action='ures.php' onsubmit='return vcheck(formname);'>
<a href='#' onclick='hideShow(allrows);'>Show/Hide All Fields</a>
<TABLE border='0' bordercolor='#COCOCO' cellpadding='0' cellspacing='4' width='75%'>
	<TR id='allrows'>
		<TD colspan='2' align='center'>
<TABLE>
	<TR>
		<TD colspan='2' align='center'>
			<B>
				Residency Application Term
			</B>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right' width='50%'>
			<B>
				Year
			</B>
			<select NAME='resiy' CLASS='formfield'>
				<option value='<?php echo $resiy;?>' selected><?php echo $resiy;?></option>
				<option></option>
				<?php
					$n = date("Y");
					for ($i = 0; $i < 10; $i++){
						echo "<option value='".$n."'>".$n."</option>\n";
						$n++;
					}
				?>
			</select>
		</TD>
		<TD width='50%'>
			<B>
				Semester
			</B>
			<select NAME='resis' CLASS='formfield'>
				<option value='<?php echo $resis;?>' selected><?php echo $term[$resis];?></option>
				<option></option>
				<option value='1'>SPRING</option>
				<option value='3'>FALL</option>
			</select>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right' width='50%'>
			<B>
				L Number
			</B>
		</TD>
		<TD width='50%'>
			<INPUT NAME='lnum' value='<?php echo $lnum;?>' SIZE='12' maxlength='10' CLASS='formfield' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right' width='50%'>
			<B>
				Last Name
			</B>
		</TD>
		<TD width='50%'>
			<INPUT NAME='lname' value='<?php echo $lname;?>' SIZE='25' CLASS='formfield' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right' width='50%'>
			<B>
				First Name
			</B>
		</TD>
		<TD width='50%'>
			<INPUT NAME='fname' value='<?php echo $fname;?>' SIZE='25' CLASS='formfield' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right' width='50%'>
			<B>
				Middle Initial
			</B>
		</TD>
		<TD width='50%'>
			<INPUT NAME='mid' value='<?php echo $mid;?>' SIZE='1' CLASS='formfield' maxlength='1' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right' width='50%'>
			<B>
				Street Address
			</B>
		</TD>
		<TD width='50%'>
			<INPUT NAME='address' value='<?php echo $address;?>' SIZE='25' CLASS='formfield' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right' width='50%'>
			<B>
				Apt/Ste/unit
			</B>
		</TD>
		<TD width='50%'>
			<INPUT NAME='unit' value='<?php echo $unit;?>' SIZE='10' CLASS='formfield' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right' width='50%'>
			<B>
				City
			</B>
		</TD>
		<TD width='50%'>
			<INPUT NAME='city' value='<?php echo $city;?>' SIZE='25' CLASS='formfield' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right' width='50%'>
			<B>
				State
			</B>
		</TD>
		<TD width='50%'>
			<INPUT NAME='state' value='<?php echo $state;?>' SIZE='3' CLASS='formfield' maxlength='2' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right' width='50%'>
			<B>
				Zip
			</B>
		</TD>
		<TD width='50%'>
			<INPUT NAME='zip' value='<?php echo $zip;?>' SIZE='7' CLASS='formfield' maxlength='5' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD colspan='2' align='center'>
			<B>
				Admit Term
			</B>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right' width='50%'>
			<B>
				Year
			</B>
			<select NAME='admity' CLASS='formfield'>
				<option value='<?php echo $admity;?>' selected><?php echo $admity;?></option>
				<option></option>
				<?php
					$n = date("Y") - 15;
					for ($i = 0; $i < 17; $i++){
						echo "<option value='".$n."'>".$n."</option>\n";
						$n++;
					}
				?>
			</select>
		</TD>
		<TD width='50%'>
			<B>
				Semester
			</B>
			<select NAME='admits' CLASS='formfield'>
				<option value='<?php echo $admits;?>' selected><?php echo $term[$admits];?></option>
				<option></option>
				<option value='1'>SPRING</option>
				<option value='2'>SUMMER</option>
				<option value='3'>FALL</option>
			</select>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right' width='50%'>
			<B>
				Residency Code
			</B>
		</TD>
		<TD width='50%'>
			<select NAME='resicode' CLASS='formfield'>
				<option value='<?php echo $resicode;?>' selected><?php echo $resicode;?></option>
				<option></option>
				<option value='A'>A</option>
				<option value='B'>B</option>
				<option value='C'>C</option>
				<option value='D'>D</option>
				<option value='E'>E</option>
				<option value='F'>F</option>
				<option value='I'>I</option>
			</select>
		</TD>
	</TR>
	</table>
			</TD>
	</TR>
	<TR id='csr'>
		<TD ALIGN='right' width='50%'>
			<B>
				CSR Name
			</B>
		</TD>
		<TD width='50%'>
			<select NAME='csrname' CLASS='formfield'>
				<?php
					if ($csrname != ''){
						echo "<option value='".$csrname."' selected>".$csrname."</option><option></option>\n";
						echo "<option></option>";
					}else{
						echo "<option>Select One</option>";
					}
					for ($i = 0; $i < count($csrs); $i++){
						echo "<option value='".$csrs[$i]."'>".$csrs[$i]."</option>";
					}
				?>
			</select>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right' width='50%'>
			<?php
				if ($status == ''){
					$fontc = '#FF0000';
				}else{
					$fontc = '#000000';
				}
				echo "<font color='".$fontc."'>";
			?>
				<B>
					Status
				</B>
			</font>
		</TD>
		<TD width='50%'>
			<select NAME='status' CLASS='formfield' onchange='check_status();'>
				<?php
				if ($status == ''){
					echo "<option selected>Select One</option>";
				}else{
					$sbgcolor = $status_color[$status];
					if ($sbgcolor == '#000000'){
						$sbgcolor = '#FFFFFF';
					}
					echo "<option value='".$status."' style='BACKGROUND-COLOR:".$sbgcolor."' selected>".$status_list[$status]."</option>\n";
				}
				for ($i = 1; $i <= 5; $i++){
					$sbgcolor = $status_color[$i];
					if ($sbgcolor == '#000000'){
						$sbgcolor = '#FFFFFF';
					}
					echo "<option value='".$i."' style='BACKGROUND-COLOR:".$sbgcolor."'>".$status_list[$i]."</option>\n";
				}
				?>
			</select>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right' width='50%'>
			<b>
				Date Denied
			</b>
		</TD>
		<TD width='50%'>
			<?php
				include ($root.'/cal/calset.php');
			?>
			<script>
				function date_change(){
					formname.ddate.value = formname.ddateview.value;
				}
			</script>
			<INPUT NAME='ddateview' VALUE='<?php echo $fdate;?>' SIZE='12' CLASS='formfield' onchange='date_change();' disabled>
			<INPUT type='hidden' NAME='ddate'>
			<img align='middle' id='img_ddate' src='/cal/calendar.gif' alt='calendar' disabled>
		</TD>
	</TR>
	<TR>
		<TD colspan='2' align='center'>
			<BR>
		</TD>
	</TR>
	<?php
		if ($notes != ''){
			echo "<TR><TD colspan='2' align='center'>";
			echo "<b>Notes History</b>";
			echo "</TD></TR>";
			echo "<TR><TD colspan='2'>";
			echo nl2br($notes);
			echo "</TD></TR>";
		}else{
		}
	?>
	<TR>
		<TD colspan='2' align='center'>
			<font color='#FF0000'>
				<B>
					Notes
				</B>
			</font>
		</TD>
	</TR>
	<TR>
		<TD colspan='2' align='center'>
			<textarea name='notes' class='formfield' cols='60' rows='8'></textarea>
			<input type='hidden' name='pnotes' value='<?php echo $notes;?><BR>'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='center' colspan='2'>
			<?php
				if ($status == '6'){
					//echo "<input type='submit' name='submit' value='Update' CLASS='formbutton' disabled>";
					//echo "<input type='reset' name='reset' value='Reset' CLASS='formbutton'>";
				}else{
					echo "<input type='submit' name='submit' value='Update' CLASS='formbutton'>";
					echo "<input type='reset' name='reset' value='Reset' CLASS='formbutton'>";
				}
			?>
		</TD>
	</TR>
	<TR>
		<TD colspan='2' align='left' id='denyrow'>
			<!--<input type='checkbox' name='b1' onclick='denyals(1);'>-->
			<input type='checkbox' name='b1' <?php echo $b1;?>>
			Lacks proof of filing income tax from Nevada (signed 1040 and W2s) or pay stubs for the past 12 months.<BR>
			<input type='checkbox' name='b2' <?php echo $b2;?>>
			Lacks Documentation to support 12 continuous months of residency prior to the first day of the semester of instruction. (Rent receipts, power bills, water bills, mortgage statements, or bank statements).<BR>
			<BR>
			<input type='checkbox' name='b3' <?php echo $b3;?>>
			Lacks Nevada Driver license, Nevada vehicle registration, Nevada voter registration, or Nevada ID issued 12 months prior to the first day of the semester of instruction.
			<BR>
			<input type='checkbox' name='b4' <?php echo $b4;?>>
			Lacks clear and convincing, objective evidence of becoming a Nevada resident.
			<BR>
			<input type='checkbox' name='b5' <?php echo $b5;?>>
			Lacks documentation proving financial independence.
			<BR>
			<input type='checkbox' name='b6' onclick='check_boxes();' <?php echo $b6;?>>
			Other
			<input type='text' name='b7' size='80%' class='formfield' disabled>
			<BR>
			All additional information must be received by
			<input type='text' name='b8' value='<?php echo $b8;?>' size='12' class='formfield'>
			<img align='middle' id='img_b8' src='/cal/calendar.gif' alt='calendar'>
			for further review of your residency application.
		</TD>
	</TR>
</TABLE>
</form>
</center>
</BODY>
</table>
<script type="text/javascript" language="javascript"  src="/cal/dlcalendar.js"></script>