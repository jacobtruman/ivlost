<?php
$root = 'c:/apache2triad/htdocs';
$ptype = 'Residency Application Update';
include($root.'/ado.php');
$dsn = 'c:/apache2triad/MINE/workstudy.mdb';
$link = ado_connect( $dsn );
$sql = "SELECT * from transcripts where (name = '".$name."') AND (tdate = '".$date."') AND (institute = '".$institute."')";
//echo $sql;
$res = ado_query( $link, $sql );

$date = $res->Fields['tdate']->Value;
$name = $res->Fields['name']->Value;
$institute = $res->Fields['institute']->Value;

ado_free_result( $res );
ado_close( $link );
?>
<HEAD>
<Title>
    <?php echo $ptype?>
</Title>
<LINK Rel='stylesheet' Type='text/css' HREF='/style.css'>
</HEAD>
<body marginwidth='0' marginheight='0' scroll='yes' vlink='#0000FF' alink='#0000FF'>
	<table class='main' cellpadding='0' cellspacing='0' border='0' width='100%' height='100%'>
		<TR valign='top'>
			<TD WIDTH='100%' height='29' colspan='3'>
				<table class='bannerframe' border='0' cellspacing='0' cellpadding='3' width='100%'>
					<tr>
						<td nowrap valign='middle' align='left' height='30' width='100%'>
						</td>
					</tr>
				</table>				
				<table border='0' cellspacing='0' cellpadding='0' width='100%' height='15'>
					<tr>
					   <td bgcolor='#D8D8D8' align='center'>
						  	<font size='4' face='Times New Roman'>
								<b>
									<?php echo $ptype?>
								</b>
							</font>
						</td>
					</tr>
				</table>
			</TD>
		 </tr>
		 <tr valign='top' height=100%>
			<td width='100%' height='100%' valign='top' colspan='2'>
<center>
<BR>
<script>
function vcheck(formname)
{

  if (formname.tdate.value == '')
  {
    alert('Please enter a date in the "Date" field.');
    formname.tdate.focus();
    return (false);
  }
  if (formname.name.value == '')
  {
    alert('Please enter a name in the "Name" field.');
    formname.name.focus();
    return (false);
  }
  if (formname.institute.value == '')
  {
    alert('Please enter an institute in the "Institute" field.');
    formname.institute.focus();
    return (false);
  }
}
</script>
<form name='formname' method='POST' action='res.php' onsubmit='return vcheck(formname);'>
<INPUT TYPE='hidden' NAME='otdate' VALUE='<?php echo $date;?>'>
<INPUT TYPE='hidden' NAME='oname' VALUE='<?php echo $name;?>'>
<INPUT TYPE='hidden' NAME='oinstitute' VALUE='<?php echo $institute;?>'>
<TABLE border='0' bordercolor='#COCOCO' cellpadding='0' cellspacing='4' width='75%'>
	<TR>
		<TD ALIGN='right'>
			Date
		</TD>
		<TD>
			<?php
				include ($root.'/cal/calset.php');
			?>
			<INPUT NAME='tdate' VALUE='<?php echo $date;?>' SIZE='25' CLASS='formfield'>
			<img align='middle' id='img_tdate' src='/cal/calendar.gif' alt='calendar'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			Student Name
		</TD>
		<TD>
			<INPUT NAME='name' VALUE='<?php echo $name;?>' SIZE='25' CLASS='formfield'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			Inststitute
		</TD>
		<TD>
			<INPUT NAME='institute' VALUE='<?php echo $institute;?>' SIZE='25' CLASS='formfield'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='center' colspan='2'>
			<input type='submit' name='submit' value='Update' CLASS='formbutton'>
			<input type='reset' name='reset' value='Reset' CLASS='formbutton'>
		</TD>
	</TR>
</TABLE>
</form>
</center>
</BODY>
</table>
<script type="text/javascript" language="javascript"  src="/cal/dlcalendar.js"></script>