<?php
$ptype = 'Transcript Search Page';
$root = 'c:/apache2triad/htdocs';
include($root.'/transcript/lookup/psearchheader.php');


$db = "c:/apache2triad/MINE/workstudy.mdb";
$conn = new COM('ADODB.Connection');
$conn->Open("DRIVER={Microsoft Access Driver (*.mdb)}; DBQ=$db");

$order = 'name, tdate';

if ($sinstitute == ''){
	$sinstitute = '..';
}
if ($name == ''){
	$name = '..';
}
if ($name == '*'){
	$sql = "SELECT * FROM transcripts ORDER BY ".$order;
	$res = $conn->Execute($sql);
}else{
	if (($name != '..') && ($sinstitute != '..')){
		$sql = "SELECT * FROM transcripts WHERE (name LIKE '%".$name."%') AND (institute = '".$sinstitute."') ORDER BY ".$order;
		$res = $conn->Execute($sql);
	}else{
		$sql = "SELECT * FROM transcripts WHERE (name LIKE '%".$name."%') OR (institute = '".$sinstitute."') ORDER BY ".$order;
		$res = $conn->Execute($sql);
	}
}
?>
</form>
<BR>
<BR>
<table width='90%' border='1' cellpadding='0' cellspacing='0' bordercolor='#C0C0C0' align='center'>
	<thead>
		<tr>
			<td><b>Date</b></td>
			<td><b>Name</b></td>
			<td><b>Institute</b></td>
		</tr>
	</thead>
<tbody>
<?php
$i = 0;
if (!isset($res)){
}else{
	while (!$res->EOF){
		$name = $res->Fields['name']->Value;
		$date = $res->Fields['tdate']->Value;
		$institute = $res->Fields['institute']->Value;
		
		echo "<tr><td>\n";
		echo $date."\n";
		echo "</td><td>\n";
		echo "<form name='formname' method='POST' action='update.php' target='_blank'>\n";
		echo "<input type='submit' value='".$name."' class='textbutton'>\n";
		echo "<input type='hidden' name='date' value='".$date."'>\n";
		echo "<input type='hidden' name='name' value='".$name."'>\n";
		echo "<input type='hidden' name='institute' value='".$institute."'>\n";
		echo "</form>\n";
		echo "</td><td>\n";
		echo $institute."</TD></TR>\n";
	$i++;
	$res->MoveNext();
	}
$res->Close();
$conn->Close();
$res = null;
$conn = null;
}
echo '</tbody></table><BR>';
echo "<center>".$i." Record(s) Found</center></table></table></body>";
?>
<!-- Created by Jacob Truman -->