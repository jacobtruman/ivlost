<?php
$root = 'c:/apache2triad/htdocs';
$ptype = 'Residency Entry';
include($root.'/ado.php');
?>
<HEAD>
<Title>
    <?php echo $ptype?>
</Title>
<LINK Rel='stylesheet' Type='text/css' HREF='/style.css'>
</HEAD>
<body marginwidth='0' marginheight='0' scroll='yes' vlink='#0000FF' alink='#0000FF'>
	<table class='main' cellpadding='0' cellspacing='0' border='0' width='100%' height='100%'>
		<TR valign='top'>
			<TD WIDTH='100%' height='29' colspan='3'>
				<table class='bannerframe' border='0' cellspacing='0' cellpadding='3' width='100%'>
					<tr>
						<td nowrap valign='middle' align='left' height='30' width='100%'>
						</td>
					</tr>
				</table>				
				<table border='0' cellspacing='0' cellpadding='0' width=100%>
					<tr>
					   <td bgcolor='#D8D8D8' align='center'>
							<?php echo $ptype?>
						</td>
					</tr>
				</table>
			</TD>
		 </tr>
		 <tr valign='top' height='100%'>
			<td width='100%' height='100%' valign='top' colspan='2'>
<center>
<BR>
<BR>
<BR>
<?php
$dsn = "c:/apache2triad/MINE/workstudy.mdb";
$link = ado_connect( $dsn );

$sql = "UPDATE transcripts SET name = '".$name."', tdate = '".$tdate."', institute = '".$institute."' WHERE (name = '".$oname."') AND (tdate = '".$otdate."') AND (institute = '".$oinstitute."')";
//echo $sql;
$res = ado_query( $link, $sql );

ado_close( $link );
$msg = "The record for <b>".$name."</b> Updated Successfully!";
$thebutton = "Click Here to Return to the Record";
$thesbutton = "Click Here to Submit Another New One?";

echo $msg;
?>
<form name='formname' method='POST' action='update.php'>
<input type='hidden' name='name' value='<?php echo $name;?>'>
<input type='hidden' name='date' value='<?php echo $tdate;?>'>
<input type='hidden' name='institute' value='<?php echo $institute;?>'>
<TABLE>
	<TR>
		<TD ALIGN='center' colspan='2'>
			<input type='submit' value='<?php echo $thebutton;?>' CLASS='textbutton'>
		</TD>
	</TR>
</TABLE>
</form>

<form>
<TABLE>
	<TR>
		<TD ALIGN='center' colspan='2'>
			<input type='submit' value='Click here to close' CLASS='textbutton' onclick='javascrip:window.close();'>
		</TD>
	</TR>
</TABLE>
</form>

<form name='formname' method='POST' action='submit.php'>
<TABLE>
	<TR>
		<TD ALIGN='center' colspan='2'>
			<input type='submit' value='<?php echo $thesbutton;?>' CLASS='textbutton'>
		</TD>
	</TR>
</TABLE>
</form>
<BR>
<BR>
<BR>
<HR>
</center>
</BODY>
</table>
<script>
setTimeout("self.close()",50000);
</script>