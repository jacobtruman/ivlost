<HEAD>
<Title>
	<?php echo $ptype;?>
</Title>
<LINK Rel='stylesheet' Type='text/css' HREF='/style.css'>
</HEAD>
<body marginwidth='0' marginheight='0' scroll='yes' vlink='#0000FF' alink='#0000FF'>
	<table class='main' cellpadding='0' cellspacing='0' border='0' width='100%' height='100%'>
		<TR valign='top'>
			<TD WIDTH='100%' height='29' colspan='3'>
				<table class='bannerframe' border='0' cellspacing='0' cellpadding='3' width=100%>
					<tr>
						<td nowrap valign='middle' align='left' height='30'>
						</td>
					</tr>
				</table>
				<table border='0' cellspacing='0' cellpadding='0' width='100%'>
					<tr>
					   <td bgcolor='#D8D8D8' align='center'>
						  	<font size='4' face='Times New Roman'>
								<?php echo $ptype?>
							</font>
						</td>
					</tr>
				</table>
			</TD>
		</TR>
		<tr valign='top'>
			<td align='center'>
			<BR>
				<table valign='top' cellpadding='0' border='0' cellspacing='0'>
					<tr>
						<td>
						<?php
						if (isset($_POST['name'])){
							$name = $_POST['name'];
						}else{
							$name = '';
						}
						if (isset($_POST['tdate'])){
							$date = $_POST['tdate'];
						}else{
							$date = '';
						}
						if (isset($_POST['sinstitute'])){
							$sinstitute = $_POST['sinstitute'];
						}else{
							$sinstitute = '';
						}
						?>
							<form BOTID='0' METHOD='POST' ACTION='<?php echo $_SERVER['PHP_SELF'];?>'>
								<font size='2' face='Verdana'>
									Name
									<BR>
									<input TYPE='TEXT' NAME='name' VALUE='<?php echo $name;?>' size='20' class='formfield'>
									<BR>
									<!--Date
									<BR>
									<input TYPE='TEXT' NAME='tdate' VALUE='<?php echo $date;?>' size='20' class='formfield'>-->
									<BR>
<?php
$db = 'c:/apache2triad/MINE/workstudy.mdb';
$conn = new COM('ADODB.Connection');
$conn->Open("DRIVER={Microsoft Access Driver (*.mdb)}; DBQ=$db");

$sql = "SELECT DISTINCT institute FROM transcripts";
$res = $conn->Execute($sql);

if (!isset($res)){
}else{
	echo 'Institute';
	echo '<BR>';
	echo "<select size='1' NAME='sinstitute' CLASS='formfield'>";
	echo "<option value='".$sinstitute."'>".$sinstitute."</option>";
	if ($sinstitute != ''){
		echo "<option value=''></option>";
	}
	while (!$res->EOF){
		$institute = $res->Fields['institute']->Value;
		echo "<option value='".$institute."' class='formfield'>".$institute."</option>";
	$res->MoveNext();
	}
	$institute = '';
	echo '</select>';
$res->Close();
$conn->Close();
$res = null;
$conn = null;
}
?>
<BR>
<BR>
<input type='submit' name='submit' value='Search' class='formbutton'>
								</font>
						</td>
					</tr>
				</table>