<?php
$ptype = 'Transcript Entry 2';
$root = 'c:/apache2triad/htdocs';
?>
<HEAD>
<Title>
    <?php echo $ptype?>
</Title>
<LINK Rel='stylesheet' Type='text/css' HREF='/style.css'>
<script>
function form_focus()
{
	formname.name.focus();
}
</script>
</HEAD>
<body marginwidth='0' marginheight='0' scroll='yes' vlink='#0000FF' alink='#0000FF' onload='form_focus();'>
	<table class='main' cellpadding='0' cellspacing='0' border='0' width='100%' height='100%'>
		<TR valign='top'>
			<TD WIDTH='100%' height='29' colspan='3'>
				<table class='bannerframe' border='0' cellspacing='0' cellpadding='3' width='100%'>
					<tr>
						<td nowrap valign='middle' align='left' height='30' width='100%'>
						</td>
					</tr>
				</table>				
				<table border='0' cellspacing='0' cellpadding='0' width=100%>
					<tr>
					   <td bgcolor='#D8D8D8' align='center'>
							<?php echo $ptype?>
						</td>
					</tr>
				</table>
			</TD>
		 </tr>
		 <tr valign='top' height=100%>
			<td width='100%' height='100%' valign='top' colspan='2'>
<center>
<BR>
<BR>
<BR>
<B>
	<?php echo $ptype;?> Site
</B>
<BR>
<BR>
<?php
if ($_POST['name'] != ''){
	echo 'The transcript from <b>'.strtoupper($_POST['institute']).'</b> for <b>'.strtoupper($_POST['name']).'</b> has been entered successfully';
}
?>
<BR>
<BR>
<script>
function vcheck(formname)
{

  if (formname.tdate.value == '')
  {
    alert('Please enter a date in the "Date" field.');
    formname.tdate.focus();
    return (false);
  }
  if (formname.name.value == '')
  {
    alert('Please enter a name in the "Name" field.');
    formname.name.focus();
    return (false);
  }
  if (formname.institute.value == '')
  {
    alert('Please enter an institute in the "Institute" field.');
    formname.institute.focus();
    return (false);
  }
}
</script>
<form name='formname' method='POST' action='<?php echo $_SERVER['PHP_SELF'];?>' onsubmit='return vcheck(this)'>
<INPUT TYPE='hidden' name='next' value='1'>
<TABLE>
	<TR>
		<TD ALIGN='right'>
			Date
		</TD>
		<TD>
			<?php
				include ($root.'/cal/calset.php');
			?>
			<INPUT NAME='tdate' VALUE='' SIZE='25' CLASS='formfield'>
			<img align='middle' id='img_tdate' src='/cal/calendar.gif' alt='calendar'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			Student Name
		</TD>
		<TD>
			<INPUT NAME='name' SIZE='25' CLASS='formfield' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			Inststitute
		</TD>
		<TD>
			<INPUT NAME='institute' SIZE='25' CLASS='formfield' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='center' colspan='2'>
			<input type='submit' value='Submit' CLASS='formbutton'>
		</TD>
	</TR>
</TABLE>
</form>
<BR>
<BR>
<BR>
<HR>
</center>
</BODY>
</table>
<script type="text/javascript" language="javascript"  src="/cal/dlcalendar.js"></script>
<?php
$name = $_POST['name'];
if (isset($name)){
$db = 'c:/apache2triad/MINE/workstudy.mdb';
$conn = new COM('ADODB.Connection');
$conn->Open("DRIVER={Microsoft Access Driver (*.mdb)}; DBQ=$db");

$sql = "INSERT INTO transcripts (tdate, name, institute) VALUES ('".$_POST['tdate']."', '".$_POST['name']."', '".$_POST['institute']."')";
$sql = strtoupper($sql);
$res = $conn->Execute($sql);

$res = null;
$conn->Close();
}
?>