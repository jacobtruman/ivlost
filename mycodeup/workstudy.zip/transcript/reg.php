<?php
$ptype = 'Transcript Entry';
$root = 'c:/apache2triad/htdocs';
?>
<HEAD>
<Title>
    <?php echo $ptype?>
</Title>
<LINK Rel='stylesheet' Type='text/css' HREF='/style.css'>
<script>
function form_focus()
{
	formname.name.focus();
}
</script>
</HEAD>
<body marginwidth='0' marginheight='0' scroll='yes' vlink='#0000FF' alink='#0000FF' onload='form_focus();'>
	<table class='main' cellpadding='0' cellspacing='0' border='0' width='100%' height='100%'>
		<TR valign='top'>
			<TD WIDTH='100%' height='29' colspan='3'>
				<table class='bannerframe' border='0' cellspacing='0' cellpadding='3' width='100%'>
					<tr>
						<td nowrap valign='middle' align='left' height='30' width='100%'>
						</td>
					</tr>
				</table>				
				<table border='0' cellspacing='0' cellpadding='0' width=100%>
					<tr>
					   <td bgcolor='#D8D8D8' align='center'>
						  	<font size='4' face='Times New Roman'>
								<?php echo $ptype?>
							</font>
						</td>
					</tr>
				</table>
			</TD>
		 </tr>
		 <tr valign='top' height=100%>
			<td width='100%' height='100%' valign='top' colspan='2'>
<center>
<BR>
<BR>
<BR>
<B>
<font face='Verdana' size='5'>
	<?php echo $ptype;?> Site
</font>
</B>
<BR>
<BR>
<?php
if ($_POST['name'] != ''){
	echo 'The transcript from <b>'.strtoupper($_POST['institute']).'</b> for <b>'.strtoupper($_POST['name']).'</b> has been entered successfully';
}
?>
<BR>
<BR>
<script>
function vcheck(formname)
{

  if (formname.name.value == '')
  {
    alert('Please enter a name in the "Name" field.');
    formname.name.focus();
    return (false);
  }
  if (formname.institute.value == '')
  {
    alert('Please enter an institute in the "Institute" field.');
    formname.institute.focus();
    return (false);
  }
}
</script>
<form name='formname' method='POST' action='<?php echo $_SERVER['PHP_SELF'];?>' onsubmit='return vcheck(this)'>
<TABLE>
	<TR>
		<TD ALIGN='right'>
			Date
		</TD>
		<TD>
			<B><?php echo date("n/j/Y");?></B>
			<INPUT TYPE='hidden' NAME='date' VALUE='<?php echo date("n/j/Y");?>'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			Student Name
		</TD>
		<TD>
			<INPUT NAME='name' SIZE='25' CLASS='formfield' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			Inststitute
		</TD>
		<TD>
			<INPUT NAME='institute' SIZE='25' CLASS='formfield' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='center' colspan='2'>
			<input type='submit' value='Submit' CLASS='formbutton'>
		</TD>
	</TR>
</TABLE>
</form>
<BR>
<BR>
<BR>
<HR>
</center>
</BODY>
<?php
$name = $_POST['name'];
if (isset($name)){
$db = 'c:/apache2triad/MINE/workstudy.mdb';
$conn = new COM('ADODB.Connection');
$conn->Open("DRIVER={Microsoft Access Driver (*.mdb)}; DBQ=$db");

$sql = "INSERT INTO transcripts (tdate, name, institute) VALUES ('".$_POST['date']."', '".$_POST['name']."', '".$_POST['institute']."')";
$sql = strtoupper($sql);
$res = $conn->Execute($sql);

$res = null;
$conn->Close();
}
?>