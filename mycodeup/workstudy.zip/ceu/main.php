<?php
$ptype = 'CEU Entry';
$root = 'c:/apache2triad/htdocs';
?>
<HEAD>
<Title>
    <?php echo $ptype?>
</Title>
<LINK Rel='stylesheet' Type='text/css' HREF='/style.css'>
</HEAD>
<body marginwidth='0' marginheight='0' scroll='yes' vlink='#0000FF' alink='#0000FF'>
	<table class='main' cellpadding='0' cellspacing='0' border='0' width='100%' height='100%'>
		<TR valign='top'>
			<TD WIDTH='100%' height='29' colspan='3'>
				<table class='bannerframe' border='0' cellspacing='0' cellpadding='3' width='100%'>
					<tr>
						<td nowrap valign='middle' align='left' height='30' width='100%'>
						</td>
					</tr>
				</table>				
				<table border='0' cellspacing='0' cellpadding='0' width=100%>
					<tr>
					   <td bgcolor='#D8D8D8' align='center'>
							<?php echo $ptype?>
						</td>
					</tr>
				</table>
			</TD>
		 </tr>
		 <tr valign='top' height=100%>
			<td width='100%' height='100%' valign='top' colspan='2'>
<center>
<BR>
<BR>
<BR>
<B>
	<?php echo $ptype;?> Site
</B>
<BR>
<BR>
<?php
//include ($root."/fcheck.php");
?>
<script>
emptyfldmsg = 'Please complete all the required fields.';
spcharsmsg = 'No special characters please.';
numsmsg = 'Numbers only please.';

function isEmpty(string) {
	if (!string){
		alert(emptyfldmsg);
		return false;
	}
}

function isProper(string) {
var iChars = "!@#$%^&*_+=<>?:~\\|?\";'{}[]";
	for (var i = 0; i < string.length; i++) {
		if (iChars.indexOf(string.charAt(i)) != -1){
			alert(spcharsmsg);
			return false;
		}
	}
	return true;
}

function isProperDigits(string) {
var iChars = "!@#$%^&*_+=<>?:~\\|?\";'{}[]abcdefghijklmnopqrstuvwxyz";
	for (var i = 0; i < string.length; i++) {
		if (iChars.indexOf(string.charAt(i)) != -1){
			alert(numsmsg);
			return false;
		}
	}
	return true;
}

function vcheck(theform)
{
	if (isEmpty(theform.sdate.value) == false){
		theform.sdate.focus();
		return false;
	}

	if (isEmpty(theform.edate.value) == false){
		theform.edate.focus();
		return false;
	}

	if (isEmpty(theform.title.value) == false){
		theform.title.focus();
		return false;
	}else if (isProper(theform.title.value) == false){
		theform.title.focus();
		return false;
	}

	if (isEmpty(theform.units.value) == false){
		theform.units.focus();
		return false;
	}

	if (isEmpty(theform.descr.value) == false){
		theform.descr.focus();
		return false;
	}else if (isProper(theform.descr.value) == false){
		theform.descr.focus();
		return false;
	}

	if (isEmpty(theform.amt.value) == false){
		theform.amt.focus();
		return false;
	}else if (isProperDigits(theform.amt.value) == false){
		theform.amt.focus();
		return false;
	}
}
</script>
<form name='formname' method='POST' action='res.php' onsubmit='return vcheck(this)'>
<TABLE>
	<TR>
		<TD ALIGN='right'>
			Start Date
		</TD>
		<TD>
			<?php
				include ($root.'/cal/calset.php');
			?>
			<INPUT NAME='sdate' VALUE='' SIZE='15' CLASS='formfield'>
			<img align='middle' id='img_sdate' src='/cal/calendar.gif' alt='calendar'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			End Date
		</TD>
		<TD>
			<?php
				include ($root.'/cal/calset.php');
			?>
			<INPUT NAME='edate' VALUE='' SIZE='15' CLASS='formfield'>
			<img align='middle' id='img_edate' src='/cal/calendar.gif' alt='calendar'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			Title
		</TD>
		<TD>
			<INPUT NAME='title' SIZE='30' CLASS='formfield' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			Units Awarded
		</TD>
		<TD>
			<INPUT NAME='units' SIZE='4' CLASS='formfield' style='text-transform: uppercase;'>
		</TD>
	</TR>
	<TR>
		<TD colspan='2' align='center'>
			<B>
				Description
			</B>
		</TD>
	</TR>
	<TR>
		<TD colspan='2' align='center'>
			<textarea name='descr' class='formfield' cols='60' rows='8' style='text-transform: uppercase;'></textarea>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='right'>
			Number of People
		</TD>
		<TD>
			<INPUT NAME='amt' SIZE='3' CLASS='formfield'>
		</TD>
	</TR>
	<TR>
		<TD ALIGN='center' colspan='2'>
			<input type='submit' value='Submit' CLASS='formbutton'>
		</TD>
	</TR>
</TABLE>
</form>
<BR>
<BR>
<BR>
<a href='file://wsentry/ceudoc' target='_blank'>Documents</a>
<HR>
</center>
</BODY>
</table>
<script type="text/javascript" language="javascript"  src="/cal/dlcalendar.js"></script>