<HEAD>
<Title>
	<?php echo $ptype;?>
</Title>
<LINK Rel='stylesheet' Type='text/css' HREF='/style.css'>
</HEAD>
<body marginwidth='0' marginheight='0' scroll='yes' vlink='#0000FF' alink='#0000FF'>
	<table class='main' cellpadding='0' cellspacing='0' border='0' width='100%' height='100%'>
		<TR valign='top'>
			<TD WIDTH='100%' height='29' colspan='3'>
				<table class='bannerframe' border='0' cellspacing='0' cellpadding='3' width=100%>
					<tr>
						<td nowrap valign='middle' align='left' height='30'>
						</td>
					</tr>
				</table>
				<table border='0' cellspacing='0' cellpadding='0' width='100%'>
					<tr>
					   <td bgcolor='#D8D8D8' align='center'>
						  	<font size='4' face='Times New Roman'>
								<?php echo $ptype?>
							</font>
						</td>
					</tr>
				</table>
			</TD>
		</TR>
		<tr valign='top'>
			<td align='center'>
			<BR>
				<table valign='top' cellpadding='0' border='0' cellspacing='0'>
					<tr>
						<td>
						<?php
						if (isset($ceu_num)){
							$ceu_num = $ceu_num;
						}else{
							$ceu_num = '';
						}
						?>
							<form BOTID='0' METHOD='POST' ACTION='labels.php' target='_blank'>
								<font size='2' face='Verdana'>
									Name
									<BR>
									<input TYPE='TEXT' NAME='ceu_num' VALUE='<?php echo $ceu_num;?>' size='20' class='formfield'>
									<BR>
									<BR>
									<input type='submit' name='submit' value='Search' class='formbutton'>
								</font>
						</td>
					</tr>
				</table>