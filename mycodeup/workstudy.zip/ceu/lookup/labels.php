<?php
$ptype = 'Transcript Search Page';
$root = 'c:/apache2triad/htdocs';

$db = "c:/apache2triad/MINE/workstudy.mdb";
$conn = new COM('ADODB.Connection');
$conn->Open("DRIVER={Microsoft Access Driver (*.mdb)}; DBQ=$db");

$order = 'ceu_num';

if ($ceu_num == '*'){
	$sql = "SELECT * FROM ceu ORDER BY ".$order;
	$res = $conn->Execute($sql);
}else{
	$sql = "SELECT * FROM ceu WHERE (ceu_num = '".$ceu_num."') ORDER BY ".$order;
	$res = $conn->Execute($sql);
}
?>
<LINK Rel='stylesheet' Type='text/css' HREF='/style.css'>
<body marginwidth='0' marginheight='0' scroll='yes' vlink='#0000FF' alink='#0000FF'>
<table border='1' cellpadding='0' cellspacing='3' bordercolor='#C0C0C0' align='center'>
<?php
$i = 0;
$width = '380';
$height = '175';
if (!isset($res)){
}else{
	while (!$res->EOF){
		$ceu_num = $res->Fields['ceu_num']->Value;
		$amt = $res->Fields['amt']->Value;
		for ($j = 0; $j <= $amt; $j++){
			if ($i % 2 == 0){
				echo "<tr><td height='".$height."' width='".$width."' valign='top'>\n";
				echo $ceu_num."</TD><td width='8'></td>\n";
			}else{
				echo "<td height='".$height."' width='".$width."' valign='top'>\n";
				echo $ceu_num."</TD></TR>\n";
			}
			$i++;
			if ($i == 10){
				echo "</table><P CLASS='breakhere'><table border='1' cellpadding='0' cellspacing='3' bordercolor='#C0C0C0' align='center'>";
				$i = 0;
			}
		}
	$res->MoveNext();
	}
$res = null;
$conn->Close();
}
echo '</table></body>';
?>
<!-- Created by Jacob Truman -->