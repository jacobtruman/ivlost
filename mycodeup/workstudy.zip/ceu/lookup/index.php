<?php
$ptype = 'Transcript Search Page';
$root = 'c:/apache2triad/htdocs';
include($root.'/ceu/lookup/psearchheader.php');


$db = "c:/apache2triad/MINE/workstudy.mdb";
$conn = new COM('ADODB.Connection');
$conn->Open("DRIVER={Microsoft Access Driver (*.mdb)}; DBQ=$db");

$order = 'ceu_num';

if ($ceu_num == '*'){
	$sql = "SELECT * FROM ceu ORDER BY ".$order;
	$res = $conn->Execute($sql);
}else{
	$sql = "SELECT * FROM ceu WHERE (ceu_num = '".$ceu_num."') ORDER BY ".$order;
	$res = $conn->Execute($sql);
}
?>
<table border='1' cellpadding='0' cellspacing='0' bordercolor='#C0C0C0' align='center'>
<tbody>
<?php
$i = 0;
$width = '300';
$height = '100';
if (!isset($res)){
}else{
	while (!$res->EOF){
		$ceu_num = $res->Fields['ceu_num']->Value;
		
		if ($i % 2 == 0){
			echo "<tr><td height='".$height."' width='".$width."' valign='top'>\n";
			echo $ceu_num."</TD><td width='8'></td>\n";
		}else{
			echo "<td height='".$height."' width='".$width."' valign='top'>\n";
			echo $ceu_num."</TD></TR>\n";
		}
		
	$i++;
	$res->MoveNext();
	}
$res = null;
$conn->Close();
}
echo '</tbody></table><BR>';
echo "</table></table></body>";
?>
<!-- Created by Jacob Truman -->