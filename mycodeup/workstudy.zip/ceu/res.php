<?php
$ptype = 'CEU Entry';
$root = 'c:/apache2triad/htdocs';
?>
<HEAD>
<Title>
    <?php echo $ptype?>
</Title>
<LINK Rel='stylesheet' Type='text/css' HREF='/style.css'>
</HEAD>
<body marginwidth='0' marginheight='0' scroll='yes' vlink='#0000FF' alink='#0000FF'>
	<table class='main' cellpadding='0' cellspacing='0' border='0' width='100%' height='100%'>
		<TR valign='top'>
			<TD WIDTH='100%' height='29' colspan='3'>
				<table class='bannerframe' border='0' cellspacing='0' cellpadding='3' width='100%'>
					<tr>
						<td nowrap valign='middle' align='left' height='30' width='100%'>
						</td>
					</tr>
				</table>				
				<table border='0' cellspacing='0' cellpadding='0' width=100%>
					<tr>
					   <td bgcolor='#D8D8D8' align='center'>
							<?php echo $ptype?>
						</td>
					</tr>
				</table>
			</TD>
		 </tr>
		 <tr valign='top' height=100%>
			<td width='100%' height='100%' valign='top' colspan='2'>
<center>
<BR>
<BR>
<?php
$filename = 'ceu_num';

$fd = fopen ($filename, "rb"); 
$contents = fread ($fd, filesize ($filename));
$val = ++$contents;
fclose ($fd); 

if (is_writable($filename)) { 


   if (!$fp = fopen($filename, 'w+')) { 
        print "Cannot open file ($filename)"; 
        exit; 
   } 

   if (!fwrite($fp, $val)) { 
       print "Cannot write to file ($filename)"; 
       exit; 
   } 
    $ceu_num = 'CEU'.$val;
    
   fclose($fp); 
                    
} else { 
   print "The file $filename is not writable"; 
}
	echo 'CEU Number <B>'.$ceu_num.'</b> Entered Successfully';
?>
<BR>
<BR>
<form name='formname' method='POST' action='main.php'>
<TABLE>
	<TR>
		<TD ALIGN='center' colspan='2'>
			<input type='submit' value='Click Here to Submit Another?' CLASS='textbutton'>
		</TD>
	</TR>
</TABLE>
</form>
<TABLE>
	<TR>
		<TD colspan='2'>
			To print you must follow these steps:
			<li>
				Make Note of the CEU Number above
			</li>
			<li>
				<a href='file://wsentry/ceudoc' target='_blank'>Click Here to Print Labels</a>
			</li>
			<li>
				Open the ceu2.doc
			</li>
			<li>
				In Word go to "Tools" -> "Mail Merge..."
			</li>
			<li>
				Click on "Query Options..."
			</li>
			<li>
				In the "Compare to:" box type in the CEU Number from above and click "OK"
			</li>
			<li>
				Click on "Close"
			</li>
			<li>
				Click on the <img src='abc.png' border='0'> button which will fill in the values
			</li>
			<li>
				Find the last label that is filled in and remove the text in the labels below
			</li>
			<li>
				Go to "File" -> "Print..."
			</li>
			<li>
				Put the proper number of pages in the printer
			</li>
			<li>
				In "Page range" select "Pages:" and put in the proper pages and click on "OK"
			</li>
		</TD>
	</TR>
</TABLE>
<BR>
<HR>
</center>
</BODY>
</table>
<?php
if (isset($amt)){
$db = 'c:/apache2triad/MINE/workstudy.mdb';
$conn = new COM('ADODB.Connection');
$conn->Open("DRIVER={Microsoft Access Driver (*.mdb)}; DBQ=$db");

$sql = "INSERT INTO ceu (ceu_num, sdate, edate, title, units, descr, amt) VALUES ('".$ceu_num."', '".$sdate."', '".$edate."', '".$title."', '".$units."', '".$descr."', '".$amt."')";
$sql = strtoupper($sql);
for ($i = 0; $i < $amt; $i++){
$res = $conn->Execute($sql);

$res = null;
}
$conn->Close();
}
?>